# SQL Manager 2005 Lite for MySQL 3.7.6.2
# ---------------------------------------
# Host     : localhost
# Port     : 3306
# Database : LatihanUAS201130010


SET FOREIGN_KEY_CHECKS=0;

DROP DATABASE IF EXISTS `LatihanUAS201130010`;

CREATE DATABASE `LatihanUAS201130010`
    CHARACTER SET 'latin1'
    COLLATE 'latin1_swedish_ci';

USE `LatihanUAS201130010`;

#
# Structure for the `customer` table : 
#

DROP TABLE IF EXISTS `customer`;

CREATE TABLE `customer` (
  `id_customer` char(10) NOT NULL,
  `nama_customer` varchar(20) NOT NULL,
  `alamat` varchar(30) default NULL,
  PRIMARY KEY  (`id_customer`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `jenis` table : 
#

DROP TABLE IF EXISTS `jenis`;

CREATE TABLE `jenis` (
  `id_jenis` char(10) NOT NULL,
  `jenis_mobil` varchar(20) NOT NULL,
  PRIMARY KEY  (`id_jenis`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `mobil` table : 
#

DROP TABLE IF EXISTS `mobil`;

CREATE TABLE `mobil` (
  `id_mobil` char(10) NOT NULL,
  `no_polisi` varchar(10) NOT NULL,
  `id_jenis` char(10) default NULL,
  `merk` varchar(20) default NULL,
  `status` varchar(20) default NULL,
  PRIMARY KEY  (`id_mobil`),
  KEY `id_jenis` (`id_jenis`),
  CONSTRAINT `mobil_fk` FOREIGN KEY (`id_jenis`) REFERENCES `jenis` (`id_jenis`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `masterpinjam` table : 
#

DROP TABLE IF EXISTS `masterpinjam`;

CREATE TABLE `masterpinjam` (
  `id_pinjam` char(11) NOT NULL,
  `id_customer` char(10) default NULL,
  `tanggal` date default NULL,
  PRIMARY KEY  (`id_pinjam`),
  KEY `id_customer` (`id_customer`),
  CONSTRAINT `masterpinjam_fk` FOREIGN KEY (`id_customer`) REFERENCES `customer` (`id_customer`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `detailpinjam` table : 
#

DROP TABLE IF EXISTS `detailpinjam`;

CREATE TABLE `detailpinjam` (
  `id_pinjam` char(10) NOT NULL,
  `id_mobil` char(10) NOT NULL,
  PRIMARY KEY  (`id_pinjam`,`id_mobil`),
  KEY `id_pinjam` (`id_pinjam`),
  KEY `id_mobil` (`id_mobil`),
  CONSTRAINT `detailpinjam_fk1` FOREIGN KEY (`id_mobil`) REFERENCES `mobil` (`id_mobil`) ON UPDATE CASCADE,
  CONSTRAINT `detailpinjam_fk` FOREIGN KEY (`id_pinjam`) REFERENCES `masterpinjam` (`id_pinjam`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TRIGGER `detailpinjam_after_ins_tr` AFTER INSERT ON `detailpinjam`
  FOR EACH ROW
BEGIN
     update mobil set status='pinjam' where id_mobil=new.id_mobil;
END;

CREATE TRIGGER `detailpinjam_after_upd_tr` AFTER UPDATE ON `detailpinjam`
  FOR EACH ROW
BEGIN
     update mobil set status = 'Kosong' where id_mobil=old.id_mobil;
     update mobil set status= 'pinjam' where id_mobil=new.id_mobil;
END;

CREATE TRIGGER `detailpinjam_before_del_tr` BEFORE DELETE ON `detailpinjam`
  FOR EACH ROW
BEGIN
     update mobil set status ='Kosong' where id_mobil = old.id_mobil;
END;

#
# Definition for the `insert_customer` procedure : 
#

DROP PROCEDURE IF EXISTS `insert_customer`;

CREATE PROCEDURE `insert_customer`(IN a CHAR(10), IN b VARCHAR(20), IN c VARCHAR(30))
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY DEFINER
    COMMENT ''
BEGIN
declare kosong tinyint default 0;
declare n char(10);
declare cur cursor for select id_customer FROM
        customer where id_customer=a;
declare continue handler FOR
        not found set kosong=1;

open cur;
fetch cur into n;
close cur;
if kosong =1 then
   insert into customer
   values (a,b,c);
   select'Data BERHASIL ditambahkan';
ELSE
update  customer set id_customer=a,nama_customer=b,alamat=c
   where id_customer=a;
   select'Data BERHASIL diupdate';
 end if;

END;

#
# Definition for the `insert_detilpinjam` procedure : 
#

DROP PROCEDURE IF EXISTS `insert_detilpinjam`;

CREATE PROCEDURE `insert_detilpinjam`(IN a CHAR(10), IN b CHAR(10))
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY DEFINER
    COMMENT ''
BEGIN
     insert into detailpinjam values(a,b);
END;

#
# Definition for the `insert_mobil` procedure : 
#

DROP PROCEDURE IF EXISTS `insert_mobil`;

CREATE PROCEDURE `insert_mobil`(IN a CHAR(10), IN b VARCHAR(10), IN c CHAR(10), IN d VARCHAR(20), IN e VARCHAR(20))
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY DEFINER
    COMMENT ''
BEGIN
declare kosong tinyint default 0;
declare n char(10);
declare cur cursor for select id_mobil FROM
        mobil where id_mobil=a;
declare continue handler FOR
        not found set kosong=1;

open cur;
fetch cur into n;
close cur;
if kosong =1 then
   insert into mobil
   values (a,b,c,d,e);
   select'Data BERHASIL ditambahkan';
ELSE
update  mobil set id_mobil=a,no_polisi=b,id_jenis=c,merk=d,status=e
   where id_mobil=a;
   select'Data BERHASIL diupdate';
 end if;

END;

#
# Definition for the `insert_pinjam` procedure : 
#

DROP PROCEDURE IF EXISTS `insert_pinjam`;

CREATE PROCEDURE `insert_pinjam`(IN a CHAR(11), IN b CHAR(10), IN c DATE)
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY DEFINER
    COMMENT ''
BEGIN
declare kosong tinyint default 0;
declare n char(10);
declare cur cursor for select id_pinjam FROM
        masterpinjam where id_pinjam=a;
declare continue handler FOR
        not found set kosong=1;

open cur;
fetch cur into n;
close cur;
if kosong =1 then
   insert into masterpinjam
   values (a,b,c);
   select'Data BERHASIL ditambahkan';
ELSE
update  masterpinjam set id_pinjam=a,id_customer=b,tanggal=c
   where id_pinjam=a;
   select'Data BERHASIL diupdate';
 end if;
END;

#
# Data for the `customer` table  (LIMIT 0,500)
#

INSERT INTO `customer` (`id_customer`, `nama_customer`, `alamat`) VALUES 
  ('2010130010','Angga Tresna','Otista 564');

COMMIT;

#
# Data for the `jenis` table  (LIMIT 0,500)
#

INSERT INTO `jenis` (`id_jenis`, `jenis_mobil`) VALUES 
  ('B001','Motor Kecil'),
  ('B002','Motor Besar'),
  ('M001','Mobil Kecil'),
  ('M002','Mobil Besar');

COMMIT;

#
# Data for the `mobil` table  (LIMIT 0,500)
#

INSERT INTO `mobil` (`id_mobil`, `no_polisi`, `id_jenis`, `merk`, `status`) VALUES 
  ('M192052012','B 9785 US','M001','Futura','Pinjam');

COMMIT;

#
# Data for the `masterpinjam` table  (LIMIT 0,500)
#

INSERT INTO `masterpinjam` (`id_pinjam`, `id_customer`, `tanggal`) VALUES 
  ('2013051301','2010130010','2013-05-13'),
  ('2013051325','2010130010','2013-05-13');

COMMIT;

#
# Data for the `detailpinjam` table  (LIMIT 0,500)
#

INSERT INTO `detailpinjam` (`id_pinjam`, `id_mobil`) VALUES 
  ('2013051301','M192052012');

COMMIT;


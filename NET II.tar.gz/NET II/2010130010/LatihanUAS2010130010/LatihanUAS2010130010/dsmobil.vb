﻿Partial Class dsmobil
End Class

Namespace dsmobilTableAdapters

    Partial Public Class mobilTableAdapter
    End Class
End Namespace

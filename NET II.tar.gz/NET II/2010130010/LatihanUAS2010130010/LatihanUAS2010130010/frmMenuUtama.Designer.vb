﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMenuUtama
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.DATAToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.KATEGORIToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MOBILToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CUSTOMERToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TRANSAKSIToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PEMINJAMANToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PENGEMBALIANToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LAPORANToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PEMINJAMANToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PENGEMBALIANToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MOBILToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.KELUARToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.id_pinjam = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.merk = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.status = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.no_polisi = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.jenis_mobil = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.id_mobil = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtid = New System.Windows.Forms.TextBox()
        Me.txtidcus = New System.Windows.Forms.TextBox()
        Me.txtnama = New System.Windows.Forms.TextBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.strRecord = New System.Windows.Forms.ToolStripStatusLabel()
        Me.MenuStrip1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DATAToolStripMenuItem, Me.TRANSAKSIToolStripMenuItem, Me.LAPORANToolStripMenuItem, Me.KELUARToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(716, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'DATAToolStripMenuItem
        '
        Me.DATAToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.KATEGORIToolStripMenuItem, Me.MOBILToolStripMenuItem, Me.CUSTOMERToolStripMenuItem})
        Me.DATAToolStripMenuItem.Name = "DATAToolStripMenuItem"
        Me.DATAToolStripMenuItem.Size = New System.Drawing.Size(46, 20)
        Me.DATAToolStripMenuItem.Text = "DATA"
        '
        'KATEGORIToolStripMenuItem
        '
        Me.KATEGORIToolStripMenuItem.Name = "KATEGORIToolStripMenuItem"
        Me.KATEGORIToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.KATEGORIToolStripMenuItem.Text = "KATEGORI"
        '
        'MOBILToolStripMenuItem
        '
        Me.MOBILToolStripMenuItem.Name = "MOBILToolStripMenuItem"
        Me.MOBILToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.MOBILToolStripMenuItem.Text = "MOBIL"
        '
        'CUSTOMERToolStripMenuItem
        '
        Me.CUSTOMERToolStripMenuItem.Name = "CUSTOMERToolStripMenuItem"
        Me.CUSTOMERToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.CUSTOMERToolStripMenuItem.Text = "CUSTOMER"
        '
        'TRANSAKSIToolStripMenuItem
        '
        Me.TRANSAKSIToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PEMINJAMANToolStripMenuItem, Me.PENGEMBALIANToolStripMenuItem})
        Me.TRANSAKSIToolStripMenuItem.Name = "TRANSAKSIToolStripMenuItem"
        Me.TRANSAKSIToolStripMenuItem.Size = New System.Drawing.Size(75, 20)
        Me.TRANSAKSIToolStripMenuItem.Text = "TRANSAKSI"
        '
        'PEMINJAMANToolStripMenuItem
        '
        Me.PEMINJAMANToolStripMenuItem.Name = "PEMINJAMANToolStripMenuItem"
        Me.PEMINJAMANToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.PEMINJAMANToolStripMenuItem.Text = "PEMINJAMAN"
        '
        'PENGEMBALIANToolStripMenuItem
        '
        Me.PENGEMBALIANToolStripMenuItem.Name = "PENGEMBALIANToolStripMenuItem"
        Me.PENGEMBALIANToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.PENGEMBALIANToolStripMenuItem.Text = "PENGEMBALIAN"
        '
        'LAPORANToolStripMenuItem
        '
        Me.LAPORANToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PEMINJAMANToolStripMenuItem1, Me.PENGEMBALIANToolStripMenuItem1, Me.MOBILToolStripMenuItem1})
        Me.LAPORANToolStripMenuItem.Name = "LAPORANToolStripMenuItem"
        Me.LAPORANToolStripMenuItem.Size = New System.Drawing.Size(66, 20)
        Me.LAPORANToolStripMenuItem.Text = "LAPORAN"
        '
        'PEMINJAMANToolStripMenuItem1
        '
        Me.PEMINJAMANToolStripMenuItem1.Name = "PEMINJAMANToolStripMenuItem1"
        Me.PEMINJAMANToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.PEMINJAMANToolStripMenuItem1.Text = "PEMINJAMAN"
        '
        'PENGEMBALIANToolStripMenuItem1
        '
        Me.PENGEMBALIANToolStripMenuItem1.Name = "PENGEMBALIANToolStripMenuItem1"
        Me.PENGEMBALIANToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.PENGEMBALIANToolStripMenuItem1.Text = "PENGEMBALIAN"
        '
        'MOBILToolStripMenuItem1
        '
        Me.MOBILToolStripMenuItem1.Name = "MOBILToolStripMenuItem1"
        Me.MOBILToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.MOBILToolStripMenuItem1.Text = "MOBIL"
        '
        'KELUARToolStripMenuItem
        '
        Me.KELUARToolStripMenuItem.Name = "KELUARToolStripMenuItem"
        Me.KELUARToolStripMenuItem.Size = New System.Drawing.Size(57, 20)
        Me.KELUARToolStripMenuItem.Text = "KELUAR"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.strRecord})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 431)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(716, 22)
        Me.StatusStrip1.TabIndex = 1
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.id_pinjam, Me.merk, Me.status, Me.no_polisi, Me.jenis_mobil, Me.id_mobil})
        Me.DataGridView1.Location = New System.Drawing.Point(12, 185)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(677, 243)
        Me.DataGridView1.TabIndex = 2
        '
        'id_pinjam
        '
        Me.id_pinjam.DataPropertyName = "id_pinjam"
        Me.id_pinjam.HeaderText = "No Pinjam"
        Me.id_pinjam.Name = "id_pinjam"
        '
        'merk
        '
        Me.merk.DataPropertyName = "merk"
        Me.merk.HeaderText = "Merk"
        Me.merk.Name = "merk"
        '
        'status
        '
        Me.status.DataPropertyName = "status"
        Me.status.HeaderText = "Status"
        Me.status.Name = "status"
        '
        'no_polisi
        '
        Me.no_polisi.DataPropertyName = "no_polisi"
        Me.no_polisi.HeaderText = "No Polisi"
        Me.no_polisi.Name = "no_polisi"
        '
        'jenis_mobil
        '
        Me.jenis_mobil.DataPropertyName = "jenis_mobil"
        Me.jenis_mobil.HeaderText = "Jenis"
        Me.jenis_mobil.Name = "jenis_mobil"
        '
        'id_mobil
        '
        Me.id_mobil.DataPropertyName = "id_mobil"
        Me.id_mobil.HeaderText = "No Mobil"
        Me.id_mobil.Name = "id_mobil"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(23, 37)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(55, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "No Pinjam"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(23, 68)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(63, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Id Customer"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(23, 99)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(82, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Nama Customer"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(418, 37)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(46, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Tanggal"
        '
        'txtid
        '
        Me.txtid.Location = New System.Drawing.Point(109, 34)
        Me.txtid.Name = "txtid"
        Me.txtid.Size = New System.Drawing.Size(150, 20)
        Me.txtid.TabIndex = 7
        '
        'txtidcus
        '
        Me.txtidcus.Location = New System.Drawing.Point(109, 65)
        Me.txtidcus.Name = "txtidcus"
        Me.txtidcus.Size = New System.Drawing.Size(150, 20)
        Me.txtidcus.TabIndex = 8
        '
        'txtnama
        '
        Me.txtnama.Location = New System.Drawing.Point(109, 96)
        Me.txtnama.Name = "txtnama"
        Me.txtnama.Size = New System.Drawing.Size(478, 20)
        Me.txtnama.TabIndex = 9
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.CustomFormat = "ddddd dd MMM yyyy"
        Me.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DateTimePicker1.Location = New System.Drawing.Point(470, 33)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker1.TabIndex = 10
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(76, 152)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 11
        Me.Button1.Text = "|<<"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(184, 152)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 12
        Me.Button2.Text = "<<"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(312, 152)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 13
        Me.Button3.Text = ">>"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(421, 152)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 23)
        Me.Button4.TabIndex = 14
        Me.Button4.Text = ">>|"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(111, 17)
        Me.ToolStripStatusLabel1.Text = "ToolStripStatusLabel1"
        '
        'strRecord
        '
        Me.strRecord.Name = "strRecord"
        Me.strRecord.Size = New System.Drawing.Size(111, 17)
        Me.strRecord.Text = "ToolStripStatusLabel2"
        '
        'frmMenuUtama
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(716, 453)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.txtnama)
        Me.Controls.Add(Me.txtidcus)
        Me.Controls.Add(Me.txtid)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmMenuUtama"
        Me.Text = "Form1"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents DATAToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents KATEGORIToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MOBILToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CUSTOMERToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TRANSAKSIToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PEMINJAMANToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PENGEMBALIANToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LAPORANToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PEMINJAMANToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PENGEMBALIANToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MOBILToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents KELUARToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents id_pinjam As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents merk As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents status As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents no_polisi As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents jenis_mobil As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents id_mobil As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtid As System.Windows.Forms.TextBox
    Friend WithEvents txtidcus As System.Windows.Forms.TextBox
    Friend WithEvents txtnama As System.Windows.Forms.TextBox
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents strRecord As System.Windows.Forms.ToolStripStatusLabel

End Class

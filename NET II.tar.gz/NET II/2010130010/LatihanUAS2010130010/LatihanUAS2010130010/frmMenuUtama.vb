﻿Imports MySql.Data.MySqlClient
Public Class frmMenuUtama
    Protected Const SQL_CONNECTION_STRING As String = _
        "Server=localhost;Port=3306;Database=LatihanUAS201130010;UID=root;PWD='likmi'"
    Private dsDetilPinjam As DataSet
    Private dtPinjam As DataTable
    Private dtDetilPinjam As DataTable
    Private dvPinjam As DataView
    Private dvDetilPinjam As DataView
    Private sda As MySqlDataAdapter
    Protected strConn As String = SQL_CONNECTION_STRING
    Private adapter As MySqlDataAdapter
    Private Sub frmMenuUtama_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CreateDataSet()
        InitializeBindings()
        BindOrdersGrid()
        ShowCurrentRecordNumber()
        konek("localhost", "3306", "root", "likmi", "LatihanUAS201130010")
        'IsiComboBox()
    End Sub
    Sub CreateDataSet()
        Try
            Dim scnnNW As New MySqlConnection(strConn)
            Dim strSQL As String = _
                "SELECT id_pinjam,id_customer,nama_customer,tanggal FROM masterpinjam a inner join " & _
                "customer using(id_customer) group by a.id_pinjam " & _
                "order by id_pinjam"

            Dim scmd As New MySqlCommand(strSQL, scnnNW)

            sda = New MySqlDataAdapter(scmd)

            Dim scb As New MySqlCommandBuilder(sda)

            dsDetilPinjam = New DataSet()
            sda.Fill(dsDetilPinjam, "Master")

            scmd.CommandText = _
                "SELECT id_pinjam,id_mobil,no_polisi,jenis_mobil,merk," & _
                "status from detailpinjam a inner join mobil " & _
                "using(id_mobil) inner join jenis using(id_jenis) order by id_pinjam,id_mobil"

            sda.Fill(dsDetilPinjam, "Detail")

            dtPinjam = dsDetilPinjam.Tables(0)
            dtDetilPinjam = dsDetilPinjam.Tables(1)

            dvPinjam = dtPinjam.DefaultView
            dvDetilPinjam = dtDetilPinjam.DefaultView

        Catch expSql As MySqlException
            MsgBox(expSql.Message, MsgBoxStyle.Critical, Me.Text)
            Exit Sub
        End Try
    End Sub

    Private Sub InitializeBindings()
        txtid.DataBindings.Clear()
        txtid.DataBindings.Add("Text", dtPinjam, "id_pinjam")
        txtidcus.DataBindings.Clear()
        txtidcus.DataBindings.Add("Text", dtPinjam, "id_customer")
        txtnama.DataBindings.Clear()
        txtnama.DataBindings.Add("Text", dtPinjam, "nama_customer")
        DateTimePicker1.DataBindings.Clear()
        DateTimePicker1.DataBindings.Add("Value", dtPinjam, "tanggal")

        AddHandler Me.BindingContext(dtPinjam).PositionChanged, _
            AddressOf dtPinjam_PositionChanged
    End Sub
    Protected Sub dtPinjam_PositionChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        BindOrdersGrid()
        ShowCurrentRecordNumber()
    End Sub

    Sub BindOrdersGrid()
        dvDetilPinjam.RowFilter = "id_pinjam = '" & txtid.Text & "'"
        DataGridView1.DataSource = dvDetilPinjam
    End Sub

    Protected Sub ShowCurrentRecordNumber()
        strRecord.Text = "Data ke " & _
           Me.BindingContext(dtPinjam).Position + 1 & " dari " & _
              dtPinjam.Rows.Count
    End Sub

    Private Sub ToolStripStatusLabel1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripStatusLabel1.Click

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.BindingContext(dtPinjam).Position = 0
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.BindingContext(dtPinjam).Position -= 1
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.BindingContext(dtPinjam).Position += 1
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Me.BindingContext(dtPinjam).Position = dtPinjam.Rows.Count - 1
    End Sub


    Private Sub MOBILToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MOBILToolStripMenuItem1.Click
        rptMobil.Show()
    End Sub

    Private Sub PEMINJAMANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PEMINJAMANToolStripMenuItem.Click
        frmpinjam.Show()
    End Sub
End Class

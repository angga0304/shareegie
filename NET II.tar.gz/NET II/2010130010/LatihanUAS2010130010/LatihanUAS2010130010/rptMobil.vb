﻿Public Class rptMobil

    Private Sub rptMobil_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'dsmobil.mobil' table. You can move, or remove it, as needed.
        Me.mobilTableAdapter.Fill(Me.dsmobil.mobil, "%%")

        Me.ReportViewer1.RefreshReport()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.mobilTableAdapter.Fill(Me.dsmobil.mobil, "%" + TextBox1.Text + "%")

        Me.ReportViewer1.RefreshReport()
    End Sub
End Class
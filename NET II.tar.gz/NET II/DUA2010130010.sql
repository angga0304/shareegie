# SQL Manager 2005 Lite for MySQL 3.7.6.2
# ---------------------------------------
# Host     : localhost
# Port     : 3306
# Database : DUA2010130010


SET FOREIGN_KEY_CHECKS=0;

DROP DATABASE IF EXISTS `DUA2010130010`;

CREATE DATABASE `DUA2010130010`
    CHARACTER SET 'latin1'
    COLLATE 'latin1_swedish_ci';

USE `DUA2010130010`;

#
# Structure for the `padepokan` table : 
#

DROP TABLE IF EXISTS `padepokan`;

CREATE TABLE `padepokan` (
  `kode_padepokan` char(7) NOT NULL,
  `nama_padepokan` varchar(30) NOT NULL,
  `pendiri` varchar(30) NOT NULL,
  `kota` varchar(20) default NULL,
  `guru_besar` tinyint(3) default '0',
  `pertarungan` int(11) default '0',
  `menang` int(11) default '0',
  PRIMARY KEY  (`kode_padepokan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Definition for the `hapus_padepokan` procedure : 
#

DROP PROCEDURE IF EXISTS `hapus_padepokan`;

CREATE PROCEDURE `hapus_padepokan`(IN a CHAR(7))
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY DEFINER
    COMMENT ''
BEGIN
     delete from padepokan where kode_padepokan = a;
     select 'data sudah terhapus HIKS';
END;

#
# Definition for the `tambah_padepokan` procedure : 
#

DROP PROCEDURE IF EXISTS `tambah_padepokan`;

CREATE PROCEDURE `tambah_padepokan`(IN a CHAR(7), IN b VARCHAR(30), IN c VARCHAR(30), IN d VARCHAR(20), IN e TINYINT(3), IN f INTEGER(11), IN g INTEGER(11))
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY DEFINER
    COMMENT ''
BEGIN
     declare continue handler for 1062
     select'data sudah ada >_<';
     insert into padepokan values(a,b,c,d,e,f,g);
     select 'Terima Kasih Data sudah Disimpan ^_^';
END;

#
# Definition for the `ubah_padepokan` procedure : 
#

DROP PROCEDURE IF EXISTS `ubah_padepokan`;

CREATE PROCEDURE `ubah_padepokan`(IN a CHAR(7), IN b VARCHAR(30), IN c VARCHAR(30), IN d VARCHAR(20), IN e TINYINT(3), IN f INTEGER(11), IN g INTEGER(11))
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY DEFINER
    COMMENT ''
BEGIN
     update padepokan set nama_padepokan = b, pendiri = c, kota = d, guru_besar=e, pertarungan = f, menang = g where kode_padepokan = a;
     select 'Data telah di ubah ^_^';
END;

#
# Definition for the `nama_tingkat` function : 
#

DROP FUNCTION IF EXISTS `nama_tingkat`;

CREATE FUNCTION `nama_tingkat`(a TINYINT(3), b INTEGER(11))
    RETURNS varchar(30)
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY DEFINER
    COMMENT ''
begin
  declare n varchar(30);
  if a>10 and b>1000 then
       set n='Dewa';
  elseif a>5 and b>500 then
       set n ='Grand Master';
  elseif a>= 0 and b>50 then
       set n ='Master';
  elseif a>= 0 and b>10 then
       set n ='Cupu';
  else
      set n ='&nbsp';
  end if;
  return(n);
end;

#
# Data for the `padepokan` table  (LIMIT 0,500)
#

INSERT INTO `padepokan` (`kode_padepokan`, `nama_padepokan`, `pendiri`, `kota`, `guru_besar`, `pertarungan`, `menang`) VALUES 
  ('2013B01','Bandung','Agung Cengos','Gajah Terbang',6,2000,700),
  ('2013C01','Cianjur','Angga','Kuda Terbang',20,3000,3000);

COMMIT;


﻿Imports MySql.Data.MySqlClient
Public Class Form1
    Dim adapter As MySqlDataAdapter
    Dim readser As MySqlDataReader
    Dim cm As CurrencyManager
    Dim st As Boolean = False
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        konek()
        Dim sqlstr As String = "select kode_perguruan,nama_perguruan,pendiri,daerah,guru_besar,pertarungan,menang,nama_tingkat(guru_besar,menang) from perguruan"
        Dim dt As New DataTable
        Try
            adapter = New MySqlDataAdapter(sqlstr, conn)
            adapter.Fill(dt)
            DataGridView1.DataSource = dt
            cm = CType(Me.BindingContext(dt),  _
                CurrencyManager)
            DataGridView1.Columns(0).HeaderText = "KODE"
            DataGridView1.Columns(1).HeaderText = "NAMA"
            DataGridView1.Columns(2).HeaderText = "PENDIRI"
            DataGridView1.Columns(3).HeaderText = "DAERAH"
            DataGridView1.Columns(4).HeaderText = "GURUBESAR"
            DataGridView1.Columns(5).HeaderText = "PERTANDINGAN"
            DataGridView1.Columns(6).HeaderText = "MENANG"
            DataGridView1.Columns(7).HeaderText = "JULUKAN"
            cm.Position = 0
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        cm.Position = 0
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        cm.Position = cm.Count - 1
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If cm.Position = cm.Count - 1 Then
            MsgBox("Akhir Record...!!!", _
                   MsgBoxStyle.Information)
        Else
            cm.Position += 1
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If cm.Position = 0 Then
            MsgBox("Awal Record...!!!", _
                   MsgBoxStyle.Information)
        Else
            cm.Position -= 1
        End If
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Close()
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        frmperguruan.Show()
    End Sub

    Public Sub reload(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Form1_Load(Me, e)
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        formubah.TextBox1.Text = DataGridView1(0, cm.Position).Value.ToString
        formubah.Show()
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        frmperguruan.Run_SQL("call hapus_perguruan('" & DataGridView1(0, cm.Position).Value.ToString & "');")
        reload(Me, e)
    End Sub
End Class

﻿Imports MySql.Data.MySqlClient
Public Class formubah
    Dim adapter As MySqlDataAdapter
    Dim readser As MySqlDataReader
    Dim cm As CurrencyManager
    Dim st As Boolean = False
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        frmperguruan.Run_SQL("call ubah_perguruan('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" _
                & TextBox4.Text & "'," & TextBox5.Text & "," & TextBox6.Text & "," & TextBox7.Text & ")")
        Form1.reload(Me, e)
        Close()
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        konek()
        Dim sqlstr As String = "select nama_perguruan,pendiri,daerah,guru_besar,pertarungan,menang from perguruan where kode_perguruan = '" _
            & TextBox1.Text & "'"
        Dim dt As New DataTable
        Try
            adapter = New MySqlDataAdapter(sqlstr, conn)
            adapter.Fill(dt)
            TextBox2.Text = dt.Rows(0)(0).ToString
            TextBox3.Text = dt.Rows(0)(1).ToString
            TextBox4.Text = dt.Rows(0)(2).ToString
            TextBox5.Text = dt.Rows(0)(3).ToString
            TextBox6.Text = dt.Rows(0)(4).ToString
            TextBox7.Text = dt.Rows(0)(5).ToString
            st = True
        Catch ex As Exception
            'MessageBox.Show(ex.Message)
            TextBox2.Text = ""
            TextBox3.Text = ""
            'TextBox4.Text = ""
            TextBox5.Text = ""
            TextBox6.Text = ""
            TextBox7.Text = ""
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        frmperguruan.Run_SQL("call hapus_perguruan('" & TextBox1.Text & "')")
        Form1.reload(Me, e)
        Close()
    End Sub
End Class
﻿Imports MySql.Data.MySqlClient
Public Class frmperguruan
    Dim adapter As MySqlDataAdapter
    Dim readser As MySqlDataReader
    Dim cm As CurrencyManager
    Dim st As Boolean = False
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Run_SQL("call tambah_perguruan('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" _
                & TextBox4.Text & "'," & TextBox5.Text & "," & TextBox6.Text & "," & TextBox7.Text & ")")
        Form1.reload(Me, e)
        Close()
    End Sub

    Public Sub Run_SQL(ByVal perintah As String)
        konek()
        Dim dt As New DataTable
        Try
            adapter = New MySqlDataAdapter(perintah, conn)
            adapter.Fill(dt)
            MsgBox(dt.Rows(0)(0).ToString, _
                   MsgBoxStyle.Information)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub Label7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label7.Click

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        
    End Sub

    Private Sub TextBox4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox4.TextChanged
    End Sub

    Private Sub TextBox4_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox4.Leave
        konek()
        Dim perintah As String = "select kodebaru('" & TextBox4.Text & "');"
        Dim dt As New DataTable
        Try
            adapter = New MySqlDataAdapter(perintah, conn)
            adapter.Fill(dt)
            TextBox1.Text = dt.Rows(0)(0).ToString
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub
End Class
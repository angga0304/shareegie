﻿Imports MySql.Data.MySqlClient
Module koneksi
    Public conn As MySqlConnection
    Public Sub konek()
        Dim connstr As String
        connstr = "server = localhost;" _
        & "port =3306; user = root;" _
        & "password=likmi; database=LatihanUTS2010130010"
        conn = New MySqlConnection(connstr)
        conn.Open()
    End Sub
End Module
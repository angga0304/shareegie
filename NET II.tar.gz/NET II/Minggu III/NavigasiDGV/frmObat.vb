Imports MySql.Data.MySqlClient
Public Class frmAnggota
    Dim adapter As MySqlDataAdapter
    Dim reader As MySqlDataReader
    Dim CM As CurrencyManager
    Dim st As Boolean = False
    Private Sub frmAnggota_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        konek()
        Dim sqlstr As String = "select * from obat"
        Dim dt As New DataTable
        Try
            adapter = New MySqlDataAdapter(sqlstr, Conn)
            adapter.Fill(dt)
            DataGridView1.DataSource = dt
            'Mendapatkan BindingManagerBase
            CM = CType(Me.BindingContext(dt),  _
                CurrencyManager)
            DataGridView1.Columns(0).HeaderText = "Kode"
            DataGridView1.Columns(1).HeaderText = "Nama"
            DataGridView1.Columns(2).HeaderText = "Tipe"
            DataGridView1.Columns(3).HeaderText = "Harga"
            DataGridView1.Columns(4).HeaderText = "Keterangan"
            'Menetapkan posisi awal
            CM.Position = 0
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            Conn.Close()
        End Try
    End Sub

    Private Sub BtnFirst_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnFirst.Click
        CM.Position = 0
    End Sub

    Private Sub BtnPrev_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnPrev.Click
        If CM.Position = 0 Then
            MsgBox("Awal Record...!!!", _
                   MsgBoxStyle.Information)
        Else
            CM.Position -= 1
        End If
    End Sub

    Private Sub BtnNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnNext.Click
        If CM.Position = CM.Count - 1 Then
            MsgBox("Akhir Record...!!!", _
                   MsgBoxStyle.Information)
        Else
            CM.Position += 1
        End If
    End Sub

    Private Sub BtnLast_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnLast.Click
        CM.Position = CM.Count - 1
    End Sub

    Private Sub btnKeluar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnKeluar.Click
        Close()
    End Sub
    Private Sub frmAnggota_Disposed(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Disposed
        Conn.Dispose()
    End Sub

    Private Sub btnLihat_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'MessageBox.Show(Format(DateTimePicker1.Value, "yyyy-mm-dd"))
    End Sub

    Private Sub btnTambah_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTambah.Click
        Dim cmd As New MySqlCommand

        cmd.CommandType = CommandType.Text
        Dim gnr As String
        If chkGenerik.Checked Then
            gnr = "1"
        Else
            gnr = "0"
        End If
        cmd.CommandText = ("insert into obat " _
            & "(kode_obat,nama_obat,tipe_obat,harga_obat," _
            & "keterangan) values ('" & txtID.Text _
            & "','" & txtNama.Text & "','" _
            & gnr & "','" & txtJK.Text & "','" _
            & txtKeterangan.Text & "')")
        konek()
        cmd.Connection = Conn
        Try
            cmd.ExecuteNonQuery()
            MsgBox("Data Telah Tersimpan !", _
                   MsgBoxStyle.Information, "Informasi")
            Conn.Close()
        Catch ex As Exception
            ' MsgBox("Data Gagal Disimpan !", _
            'MsgBoxStyle.Exclamation, "Pesan")
            MsgBox(ex.Message.ToString, _
                   MsgBoxStyle.Information, "Pesan")
        End Try
        frmAnggota_Load(Me, e)
    End Sub

    Private Sub btnHapus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHapus.Click
        Run_SQL("", "")
        Dim cmd As New MySqlCommand

        cmd.CommandType = CommandType.Text
        cmd.CommandText = ("delete from obat where kode_obat='" & txtID.Text & "'")
        konek()
        cmd.Connection = Conn
        Try
            cmd.ExecuteNonQuery()
            MsgBox("Data Telah Terhapus !", _
                   MsgBoxStyle.Information, "Informasi")
            Conn.Close()
        Catch ex As Exception
            ' MsgBox("Data Gagal Disimpan !", _
            'MsgBoxStyle.Exclamation, "Pesan")
            MsgBox(ex.Message.ToString, _
                   MsgBoxStyle.Information, "Pesan")
        End Try
        frmAnggota_Load(Me, e)
    End Sub

    Private Sub txtID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtID.TextChanged
        konek()
        Dim sqlstr As String = "select nama_obat,tipe_obat," _
            & "harga_obat,keterangan " _
            & "from obat where kode_obat='" _
            & txtID.Text & "'"
        Dim dt As New DataTable
        Try
            adapter = New MySqlDataAdapter(sqlstr, Conn)
            adapter.Fill(dt)
            txtNama.Text = dt.Rows(0)(0).ToString
            If dt.Rows(0)(1).ToString = "1" Then
                chkGenerik.Checked = True
            Else
                chkGenerik.Checked = False
            End If
            txtJK.Text = dt.Rows(0)(2).ToString
            txtKeterangan.Text = dt.Rows(0)(3).ToString
            st = True
        Catch ex As Exception
            'MessageBox.Show(ex.Message)
            txtNama.Text = ""
            'txtAlamat.Text = ""
            txtJK.Text = ""
            chkGenerik.Checked = False
            txtKeterangan.Text = ""
            st = False
        Finally
            Conn.Close()
        End Try
    End Sub

    Private Sub Run_SQL(ByVal perintah As String, ByVal msg As String)
        Dim cmd As New MySqlCommand
        cmd.CommandType = CommandType.Text
        cmd.CommandText = (perintah)
        konek()
        cmd.Connection = Conn
        Try
            cmd.ExecuteNonQuery()
            MsgBox(msg, MsgBoxStyle.Information, "Informasi")
            Conn.Close()
        Catch ex As Exception
            ' MsgBox("Data Gagal Disimpan !", _
            'MsgBoxStyle.Exclamation, "Pesan")
            MsgBox(ex.Message.ToString, _
                   MsgBoxStyle.Information, "Pesan")
        End Try
        'frmAnggota_Load(Me, e)
    End Sub

    Private Sub btnBaru_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBaru.Click
        txtID.Text = ""
    End Sub
End Class

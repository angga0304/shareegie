﻿Imports MySql.Data.MySqlClient
Public Class frmanimal
    Dim adapter As MySqlDataAdapter
    Dim reader As MySqlDataReader
    Dim CM As CurrencyManager
    Dim st As Boolean = False
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        CM.Position = 0
    End Sub

    Private Sub frmanimal_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        konek()
        Dim sqlstr As String = "select * from animal"
        Dim dt As New DataTable
        Try
            adapter = New MySqlDataAdapter(sqlstr, Conn)
            adapter.Fill(dt)
            DataGridView1.DataSource = dt
            'Mendapatkan BindingManagerBase
            CM = CType(Me.BindingContext(dt),  _
                CurrencyManager)
            DataGridView1.Columns(0).HeaderText = "Kode"
            DataGridView1.Columns(1).HeaderText = "Nama"
            DataGridView1.Columns(2).HeaderText = "Kategori"
            DataGridView1.Columns(3).HeaderText = "Peranakan"
            DataGridView1.Columns(4).HeaderText = "Lahir"
            DataGridView1.Columns(5).HeaderText = "Kelamin"
            DataGridView1.Columns(6).HeaderText = "Terdaftar"
            DataGridView1.Columns(7).HeaderText = "Warna"
            DataGridView1.Columns(8).HeaderText = "Wani Piro"
            'Menetapkan posisi awal
            CM.Position = 0
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            Conn.Close()
        End Try
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        CM.Position = CM.Count - 1
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If CM.Position = CM.Count - 1 Then
            MsgBox("Akhir Record...!!!", _
                   MsgBoxStyle.Information)
        Else
            CM.Position += 1
        End If
    End Sub

    Private Sub Button2_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If CM.Position = 0 Then
            MsgBox("Awal Record...!!!", _
                   MsgBoxStyle.Information)
        Else
            CM.Position -= 1
        End If
    End Sub

    Private Sub btnTambah_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTambah.Click
        konek()
        Dim sqlstr As String = "call tambah_hewan(" _
                    & TextBox1.Text & ",'" & TextBox2.Text _
                    & "','" & TextBox3.Text & "','" & TextBox4.Text _
                    & "','" & Format(DateTimePicker1.Value, "yyyy-mm-dd") _
                    & "','" & TextBox5.Text & "','" & TextBox6.Text _
                    & "','" & TextBox7.Text & "'," & TextBox8.Text _
                    & ")"

        Dim dt As New DataTable
        Try
            adapter = New MySqlDataAdapter(sqlstr, Conn)
            adapter.Fill(dt)
            MsgBox(dt.Rows(0)(0).ToString, _
                   MsgBoxStyle.Information)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            Conn.Close()
        End Try
        frmanimal_Load(Me, e)
    End Sub

    Private Sub btnBaru_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBaru.Click
        konek()
        Dim sqlstr As String = "select kode_baru()"

        Dim dt As New DataTable
        Try
            adapter = New MySqlDataAdapter(sqlstr, Conn)
            adapter.Fill(dt)
            TextBox1.Text = dt.Rows(0)(0).ToString
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            Conn.Close()
        End Try
        frmanimal_Load(Me, e)
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        konek()
        Dim sqlstr As String = "select name,category,breed,dateborn,gender,registered,color,listprice from animal where animalid=" _
            & TextBox1.Text
        Dim dt As New DataTable
        Try
            adapter = New MySqlDataAdapter(sqlstr, Conn)
            adapter.Fill(dt)
            TextBox2.Text = dt.Rows(0)(0).ToString
            TextBox3.Text = dt.Rows(0)(1).ToString
            TextBox4.Text = dt.Rows(0)(2).ToString
            DateTimePicker1.Value = dt.Rows(0)(3)
            TextBox5.Text = dt.Rows(0)(4).ToString
            TextBox6.Text = dt.Rows(0)(5).ToString
            TextBox7.Text = dt.Rows(0)(6).ToString
            TextBox8.Text = dt.Rows(0)(7).ToString
            st = True
        Catch ex As Exception
            'MessageBox.Show(ex.Message)
            TextBox2.Text = ""
            TextBox3.Text = ""
            TextBox4.Text = ""
            TextBox5.Text = ""
            TextBox6.Text = ""
            TextBox7.Text = ""
            TextBox8.Text = ""
            DateTimePicker1.Value = Convert.ToDateTime("03 / 04 / 1992")
            st = False
        Finally
            Conn.Close()
        End Try
    End Sub

    Private Sub btnKeluar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnKeluar.Click
        Close()
    End Sub
End Class
﻿Imports MySql.Data.MySqlClient
Module koneksi
    Public Conn As MySqlConnection
    Public Sub konek()
        Dim Connstr As String
        Connstr = "server=localhost;" _
            & "port=3306;user=root;" _
            & "password='likmi';" _
            & "database=bsatu"
        Conn = New MySqlConnection(Connstr)
        Conn.Open()
    End Sub

End Module

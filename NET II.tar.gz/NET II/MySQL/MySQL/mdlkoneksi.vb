﻿Imports MySQL.Data.MySqlClient
Module mdlkoneksi
    Public conn As MySqlConnection
    Public Sub konek(ByVal a As String, _
                     ByVal b As String, _
                     ByVal c As String, _
                     ByVal d As String, _
                     ByVal e As String)
        Dim connstr As String
        connstr = "server=" & a & ";port=" _
            & b & ";user=" _
            & c & ";password='" _
            & d & "';database=" & e
        conn = New MySqlConnection(connstr)
        conn.Open()
    End Sub
End Module

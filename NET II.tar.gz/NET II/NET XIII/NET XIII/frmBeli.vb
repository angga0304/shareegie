﻿Imports MySql.Data.MySqlClient
Public Class frmBeli
    Protected Const SQL_CONNECTION_STRING As String = _
        "Server=localhost;Port=3306;Database=net_xiii;UID=root;PWD='likmi'"
    Private dsDetilBeli As DataSet
    Private dtBeli As DataTable
    Private dtDetilBeli As DataTable
    Private dvBeli As DataView
    Private dvDetilBeli As DataView
    Private sda As MySqlDataAdapter
    Protected strConn As String = SQL_CONNECTION_STRING
    Private adapter As MySqlDataAdapter
    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs)

    End Sub

    Sub CreateDataSet()
        Try
            Dim scnnNW As New MySqlConnection(strConn)
            Dim strSQL As String = _
                "SELECT no_beli,tanggal_beli,kode_supplier,nama_supplier," & _
                "sum(banyak*harga) as total " & _
                "FROM beli a inner join detil_beli b using(no_beli) inner join " & _
                "supplier using(kode_supplier) group by a.no_beli " & _
                "order by no_beli"

            Dim scmd As New MySqlCommand(strSQL, scnnNW)

            sda = New MySqlDataAdapter(scmd)

            Dim scb As New MySqlCommandBuilder(sda)

            dsDetilBeli = New DataSet()
            sda.Fill(dsDetilBeli, "Beli")

            scmd.CommandText = _
                "SELECT no_beli,kode_barang,nama_barang,harga,banyak," & _
                "harga*banyak as jumlah from detil_beli a inner join barang " & _
                "using(kode_barang) order by no_beli,kode_barang"

            sda.Fill(dsDetilBeli, "DetilBeli")

            dtBeli = dsDetilBeli.Tables(0)
            dtDetilBeli = dsDetilBeli.Tables(1)

            dvBeli = dtBeli.DefaultView
            dvDetilBeli = dtDetilBeli.DefaultView

        Catch expSql As MySqlException
            MsgBox(expSql.Message, MsgBoxStyle.Critical, Me.Text)
            Exit Sub
        End Try
    End Sub
    Private Sub InitializeBindings()
        TextBox1.DataBindings.Clear()
        TextBox1.DataBindings.Add("Text", dtBeli, "no_beli")
        TextBox2.DataBindings.Clear()
        TextBox2.DataBindings.Add("Text", dtBeli, "kode_supplier")
        TextBox3.DataBindings.Clear()
        TextBox3.DataBindings.Add("Text", dtBeli, "nama_supplier")
        TextBox4.DataBindings.Clear()
        TextBox4.DataBindings.Add("Text", dtBeli, "total")
        DateTimePicker1.DataBindings.Clear()
        DateTimePicker1.DataBindings.Add("Value", dtBeli, "tanggal_beli")

        AddHandler Me.BindingContext(dtBeli).PositionChanged, _
            AddressOf dtBeli_PositionChanged
    End Sub
    Protected Sub dtBeli_PositionChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        BindOrdersGrid()
        ShowCurrentRecordNumber()
    End Sub

    Sub BindOrdersGrid()
        dvDetilBeli.RowFilter = "no_beli = '" & TextBox1.Text & "'"
        DataGridView1.DataSource = dvDetilBeli
    End Sub

    Protected Sub ShowCurrentRecordNumber()
        strRecord.Text = "Data ke " & _
           Me.BindingContext(dtBeli).Position + 1 & " dari " & _
              dtBeli.Rows.Count
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.BindingContext(dtBeli).Position = 0
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.BindingContext(dtBeli).Position -= 1
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.BindingContext(dtBeli).Position += 1
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Me.BindingContext(dtBeli).Position = dtBeli.Rows.Count - 1
    End Sub

    Private Sub frmBeli_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CreateDataSet()
        InitializeBindings()
        BindOrdersGrid()
        ShowCurrentRecordNumber()
        konek("localhost", "3306", "root", "likmi", "net_xiii")
        IsiComboBox()
    End Sub

    Sub IsiComboBox()
        Dim dt As New DataTable
        Try
            adapter = New MySqlDataAdapter( _
                "select nama_supplier from " & _
                "supplier order by nama_supplier", Conn)
            adapter.Fill(dt)
            ComboBox1.Items.Clear()
            For i = 0 To dt.Rows.Count - 1
                ComboBox1.Items.Add(dt.Rows(i)(0).ToString)
            Next i
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            Conn.Close()
        End Try
    End Sub

    Private Sub eksekusi(ByVal str1 As String)
        Dim sqlstr As String = str1
        Dim dt As New DataTable
        Try
            adapter = New MySqlDataAdapter(sqlstr, Conn)
            adapter.Fill(dt)
            'MsgBox(dt.Rows(0)(0).ToString, _
            '       MsgBoxStyle.Information, "Informasi")
        Catch ex As Exception
            'MsgBox(ex.Message.ToString, _
            '       MsgBoxStyle.Information, "Pesan")
        End Try
        Conn.Close()
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        eksekusi("call insert_beli('" & _
                 TextBox5.Text & "','" & _
                 Format(DateTimePicker2.Value, "yyyy-MM-dd") & _
                 "','" & TextBox6.Text & "')")
        For i = 0 To DataGridView2.Rows.Count - 2
            eksekusi("call insert_detil_beli('" & _
                 TextBox5.Text & "','" & _
                 DataGridView2(0, i).Value & "','" & _
                 DataGridView2(3, i).Value & "','" & _
                 DataGridView2(2, i).Value & "')")
        Next i
        frmBeli_Load(Me, e)
    End Sub

    Private Sub DataGridView2_CellLeave(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView2.CellLeave
        TextBox7.Text = caritotal(DataGridView2)
        DataGridView2(4, DataGridView2.CurrentCell.RowIndex).Value = DataGridView2(3, DataGridView2.CurrentCell.RowIndex).Value * DataGridView2(2, DataGridView2.CurrentCell.RowIndex).Value
        If (DataGridView2.CurrentCell.ColumnIndex = 3) Then
            SendKeys.Send("{down}")
            SendKeys.Send("{left}")
            SendKeys.Send("{left}")
            SendKeys.Send("{left}")
            SendKeys.Send("{left}")
        End If
    End Sub

    Private Function caritotal(ByVal tabel As DataGridView) As Double
        Dim nilai As Double = 0
        For i = 0 To tabel.Rows.Count
            nilai = Val(TextBox7.Text) + tabel(4, tabel.CurrentCell.RowIndex).Value
        Next i
        Return nilai
    End Function

    Private Sub DataGridView2_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles DataGridView2.KeyPress
        If (e.KeyChar = Chr(13)) And _
            (DataGridView2.CurrentCell.ColumnIndex < 4) _
            Then
            SendKeys.Send("{up}")
            SendKeys.Send("{right}")
        End If
    End Sub

    Private Sub DataGridView2_CellEndEdit(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView2.CellEndEdit
        If DataGridView2.CurrentCell.ColumnIndex < 4 Then
            If DataGridView2.CurrentCell.ColumnIndex = 0 Then
                CariBarang(DataGridView2.CurrentCell.Value)
                SendKeys.Send("{up}")
                SendKeys.Send("{right}")
                SendKeys.Send("{right}")
                SendKeys.Send("{right}")
            Else
                SendKeys.Send("{up}")
                SendKeys.Send("{right}")
            End If
        End If
    End Sub

    Public Sub CariBarang(ByVal str As String)
        Dim dt As New DataTable
        Try
            adapter = New MySqlDataAdapter( _
                "select nama_barang,harga_barang from barang " & _
                "where kode_barang='" & _
                str & "'", Conn)
            adapter.Fill(dt)
            DataGridView2(1, DataGridView2.CurrentCell.RowIndex).Value = _
                dt.Rows(0)(0).ToString
            DataGridView2(2, DataGridView2.CurrentCell.RowIndex).Value = _
                dt.Rows(0)(1).ToString
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            Conn.Close()
        End Try
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        Dim dt As New DataTable
        Try
            adapter = New MySqlDataAdapter( _
                "select kode_supplier from " & _
                "supplier where nama_supplier='" & _
                ComboBox1.Text & "'", Conn)
            adapter.Fill(dt)
            TextBox6.Text = dt.Rows(0)(0).ToString
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            Conn.Close()
        End Try
    End Sub

    Private Sub TabPage2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TabPage2.Click

    End Sub
End Class
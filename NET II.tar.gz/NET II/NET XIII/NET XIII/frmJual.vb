﻿Imports MySql.Data.MySqlClient
Public Class frmJual
    Protected Const SQL_CONNECTION_STRING As String = _
        "Server=localhost;Port=3306;Database=net_xiii;UID=root;PWD='likmi'"
    Private dsDetilJual As DataSet
    Private dtJual As DataTable
    Private dtDetilJual As DataTable
    Private dvJual As DataView
    Private dvDetilJual As DataView
    Private sda As MySqlDataAdapter
    Protected strConn As String = SQL_CONNECTION_STRING
    Private adapter As MySqlDataAdapter

    Private Sub btnKeluar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnKeluar.Click
        Close()
    End Sub

    Private Sub frmJual_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        CreateDataSet()
        InitializeBindings()
        BindOrdersGrid()
        ShowCurrentRecordNumber()
        konek("localhost", "3306", "root", "likmi", "net_xiii")
        IsiComboBox()
    End Sub

    Sub CreateDataSet()
        Try
            Dim scnnNW As New MySqlConnection(strConn)
            Dim strSQL As String = _
                "SELECT no_jual,tanggal_jual,kode_pelanggan,nama_pelanggan," & _
                "sum(banyak*harga) as total " & _
                "FROM jual a inner join detil_jual b using(no_jual) inner join " & _
                "pelanggan using(kode_pelanggan) group by a.no_jual " & _
                "order by no_jual"

            Dim scmd As New MySqlCommand(strSQL, scnnNW)

            sda = New MySqlDataAdapter(scmd)

            Dim scb As New MySqlCommandBuilder(sda)

            dsDetilJual = New DataSet()
            sda.Fill(dsDetilJual, "Jual")

            scmd.CommandText = _
                "SELECT no_jual,kode_barang,nama_barang,harga,banyak," & _
                "harga*banyak as jumlah from detil_jual a inner join barang " & _
                "using(kode_barang) order by no_jual,kode_barang"

            sda.Fill(dsDetilJual, "DetilJual")

            dtJual = dsDetilJual.Tables(0)
            dtDetilJual = dsDetilJual.Tables(1)

            dvJual = dtJual.DefaultView
            dvDetilJual = dtDetilJual.DefaultView

        Catch expSql As MySqlException
            MsgBox(expSql.Message, MsgBoxStyle.Critical, Me.Text)
            Exit Sub
        End Try
    End Sub

    Private Sub InitializeBindings()
        lblDspNo.DataBindings.Clear()
        lblDspNo.DataBindings.Add("Text", dtJual, "no_jual")
        txtDspNo.DataBindings.Clear()
        txtDspNo.DataBindings.Add("Text", dtJual, "kode_pelanggan")
        txtDspNama.DataBindings.Clear()
        txtDspNama.DataBindings.Add("Text", dtJual, "nama_pelanggan")
        lblDspTotal.DataBindings.Clear()
        lblDspTotal.DataBindings.Add("Text", dtJual, "total")
        dtpDspTanggal.DataBindings.Clear()
        dtpDspTanggal.DataBindings.Add("Value", dtJual, "tanggal_jual")

        AddHandler Me.BindingContext(dtJual).PositionChanged, _
            AddressOf dtJual_PositionChanged
    End Sub

    Protected Sub dtJual_PositionChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        BindOrdersGrid()
        ShowCurrentRecordNumber()
    End Sub

    Sub BindOrdersGrid()
        dvDetilJual.RowFilter = "no_jual = '" & lblDspNo.Text & "'"
        dgvDsp.DataSource = dvDetilJual
    End Sub

    Protected Sub ShowCurrentRecordNumber()
        strRecord.Text = "Data ke " & _
            Me.BindingContext(dtJual).Position + 1 & " dari " & _
                dtJual.Rows.Count
    End Sub

    Private Sub btnLast_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLast.Click
        LastRecord()
    End Sub

    Public Sub FirstRecord()
        Me.BindingContext(dtJual).Position = 0
    End Sub

    Public Sub LastRecord()
        Me.BindingContext(dtJual).Position = dtJual.Rows.Count - 1
    End Sub

    Public Sub NextRecord()
        Me.BindingContext(dtJual).Position += 1
    End Sub

    Public Sub PreviousRecord()
        Me.BindingContext(dtJual).Position -= 1
    End Sub

    Private Sub btnNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNext.Click
        NextRecord()
    End Sub

    Private Sub btnPrevious_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrevious.Click
        PreviousRecord()
    End Sub

    Private Sub btnFirst_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFirst.Click
        FirstRecord()
    End Sub

    Private Sub btnBaru_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBaru.Click
        NoBaru()
        SetTanggal()
        dgvDetail.Rows.Clear()
    End Sub

    Sub IsiComboBox()
        Dim dt As New DataTable
        Try
            adapter = New MySqlDataAdapter( _
                "select nama_pelanggan from " & _
                "pelanggan order by nama_pelanggan", Conn)
            adapter.Fill(dt)
            cmbNama.Items.Clear()
            For i = 0 To dt.Rows.Count - 1
                cmbNama.Items.Add(dt.Rows(i)(0).ToString)
            Next i
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            Conn.Close()
        End Try
    End Sub

    Sub SetTanggal()
        dtpTanggal.Value = Now
    End Sub

    Sub NoBaru()
        Dim dt As New DataTable
        Try
            adapter = New MySqlDataAdapter( _
                "select nojual_baru()", Conn)
            adapter.Fill(dt)
            lblNO.Text = dt.Rows(0)(0).ToString
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            Conn.Close()
        End Try
    End Sub
    Private Sub eksekusi(ByVal str1 As String)
        Dim sqlstr As String = str1
        Dim dt As New DataTable
        Try
            adapter = New MySqlDataAdapter(sqlstr, Conn)
            adapter.Fill(dt)
            'MsgBox(dt.Rows(0)(0).ToString, _
            '       MsgBoxStyle.Information, "Informasi")
        Catch ex As Exception
            'MsgBox(ex.Message.ToString, _
            '       MsgBoxStyle.Information, "Pesan")
        End Try
        Conn.Close()
    End Sub

    Private Sub cmbNama_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbNama.SelectedIndexChanged
        Dim dt As New DataTable
        Try
            adapter = New MySqlDataAdapter( _
                "select kode_pelanggan from " & _
                "pelanggan where nama_pelanggan='" & _
                cmbNama.Text & "'", Conn)
            adapter.Fill(dt)
            txtNO.Text = dt.Rows(0)(0).ToString
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            Conn.Close()
        End Try
    End Sub

    Private Sub dgvDetail_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles dgvDetail.KeyPress
        If (e.KeyChar = Chr(13)) And _
            (dgvDetail.CurrentCell.ColumnIndex < 4) _
            Then
            SendKeys.Send("{up}")
            SendKeys.Send("{right}")
        End If
    End Sub

    Private Sub dgvDetail_CellEndEdit(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvDetail.CellEndEdit
        If dgvDetail.CurrentCell.ColumnIndex < 4 Then
            If dgvDetail.CurrentCell.ColumnIndex = 0 Then
                CariBarang(dgvDetail.CurrentCell.Value)
                SendKeys.Send("{up}")
                SendKeys.Send("{right}")
                SendKeys.Send("{right}")
                SendKeys.Send("{right}")
            Else
                SendKeys.Send("{up}")
                SendKeys.Send("{right}")
            End If
        End If
    End Sub

    Public Sub CariBarang(ByVal str As String)
        Dim dt As New DataTable
        Try
            adapter = New MySqlDataAdapter( _
                "select nama_barang,harga_barang from barang " & _
                "where kode_barang='" & _
                str & "'", Conn)
            adapter.Fill(dt)
            dgvDetail(1, dgvDetail.CurrentCell.RowIndex).Value = _
                dt.Rows(0)(0).ToString
            dgvDetail(2, dgvDetail.CurrentCell.RowIndex).Value = _
                dt.Rows(0)(1).ToString
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            Conn.Close()
        End Try
    End Sub
    
    Private Sub btnSimpan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSimpan.Click
        eksekusi("call insert_jual('" & _
                 lblNO.Text & "','" & _
                 Format(dtpTanggal.Value, "yyyy-MM-dd") & _
                 "','" & txtNO.Text & "')")
        For i = 0 To dgvDetail.Rows.Count - 2
            eksekusi("call insert_detil_jual('" & _
                 lblNO.Text & "','" & _
                 dgvDetail(0, i).Value & "','" & _
                 dgvDetail(3, i).Value & "','" & _
                 dgvDetail(2, i).Value & "')")
        Next i
        frmJual_Load(Me, e)
    End Sub

    Private Sub TabControl1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TabControl1.SelectedIndexChanged
        BindOrdersGrid()
    End Sub

    Private Sub dgvDetail_CellLeave(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvDetail.CellLeave
        dgvDetail(4, dgvDetail.CurrentCell.RowIndex).Value = dgvDetail(3, dgvDetail.CurrentCell.RowIndex).Value * dgvDetail(2, dgvDetail.CurrentCell.RowIndex).Value
        If (dgvDetail.CurrentCell.ColumnIndex = 3) Then
            SendKeys.Send("{down}")
            SendKeys.Send("{left}")
            SendKeys.Send("{left}")
            SendKeys.Send("{left}")
            SendKeys.Send("{left}")
        End If
    End Sub

    Private Sub dtpDspTanggal_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dtpDspTanggal.ValueChanged

    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub
End Class

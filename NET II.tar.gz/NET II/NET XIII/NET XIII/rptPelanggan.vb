﻿Public Class rptPelanggan

    Private Sub rptPelanggan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.PelangganTableAdapter1.Fill(Me.Net_xii1.pelanggan)
        Me.ReportViewer1.RefreshReport()
    End Sub
End Class
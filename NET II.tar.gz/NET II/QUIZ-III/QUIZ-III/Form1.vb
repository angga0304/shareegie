﻿Imports MySql.Data.MySqlClient
Public Class Form1
    Protected Const SQL_CONNECTION_STRING As String = _
        "Server=localhost;Port=3306;Database=QUIZIII2010130010;UID=root;PWD='likmi'"
    Private dsDetilJual As DataSet
    Private dtJual As DataTable
    Private dtDetilJual As DataTable
    Private dvJual As DataView
    Private dvDetilJual As DataView
    Private sda As MySqlDataAdapter
    Protected strConn As String = SQL_CONNECTION_STRING
    Private adapter As MySqlDataAdapter
    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CreateDataSet()
        InitializeBindings()
        BindOrdersGrid()
        ShowCurrentRecordNumber()
        konek("localhost", "3306", "root", "likmi", "QUIZIII2010130010")
        IsiComboBox()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Close()
    End Sub
    Sub CreateDataSet()
        Try
            Dim scnnNW As New MySqlConnection(strConn)
            Dim strSQL As String = _
                "SELECT no_jual,tanggal,kode_pelanggan,nama_pelanggan," & _
                "sum(banyak*harga) as total " & _
                "FROM jual a inner join djual b using(no_jual) inner join " & _
                "pelanggan using(kode_pelanggan) group by a.no_jual " & _
                "order by no_jual"

            Dim scmd As New MySqlCommand(strSQL, scnnNW)

            sda = New MySqlDataAdapter(scmd)

            Dim scb As New MySqlCommandBuilder(sda)

            dsDetilJual = New DataSet()
            sda.Fill(dsDetilJual, "Jual")

            scmd.CommandText = _
                "SELECT no_jual,no_buku,judul,harga,banyak," & _
                "harga*banyak as jumlah from djual a inner join buku " & _
                "using(no_buku) order by no_jual,no_buku"

            sda.Fill(dsDetilJual, "DetilJual")

            dtJual = dsDetilJual.Tables(0)
            dtDetilJual = dsDetilJual.Tables(1)

            dvJual = dtJual.DefaultView
            dvDetilJual = dtDetilJual.DefaultView

        Catch expSql As MySqlException
            MsgBox(expSql.Message, MsgBoxStyle.Critical, Me.Text)
            Exit Sub
        End Try
    End Sub

    Private Sub InitializeBindings()
        viewno.DataBindings.Clear()
        viewno.DataBindings.Add("Text", dtJual, "no_jual")
        viewkd.DataBindings.Clear()
        viewkd.DataBindings.Add("Text", dtJual, "kode_pelanggan")
        viewnama.DataBindings.Clear()
        viewnama.DataBindings.Add("Text", dtJual, "nama_pelanggan")
        viewtotal.DataBindings.Clear()
        viewtotal.DataBindings.Add("Text", dtJual, "total")
        dtp2.DataBindings.Clear()
        dtp2.DataBindings.Add("Value", dtJual, "tanggal")

        AddHandler Me.BindingContext(dtJual).PositionChanged, _
            AddressOf dtJual_PositionChanged
    End Sub

    Protected Sub dtJual_PositionChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        BindOrdersGrid()
        ShowCurrentRecordNumber()
    End Sub

    Sub BindOrdersGrid()
        dvDetilJual.RowFilter = "no_jual = '" & viewno.Text & "'"
        DataGridView2.DataSource = dvDetilJual
    End Sub

    Protected Sub ShowCurrentRecordNumber()
        strRecord.Text = "Data ke " & _
            Me.BindingContext(dtJual).Position + 1 & " dari " & _
                dtJual.Rows.Count
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.BindingContext(dtJual).Position = 0
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Me.BindingContext(dtJual).Position = dtJual.Rows.Count - 1
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Me.BindingContext(dtJual).Position += 1
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.BindingContext(dtJual).Position -= 1
    End Sub

    Sub IsiComboBox()
        Dim dt As New DataTable
        Try
            adapter = New MySqlDataAdapter( _
                "select nama_pelanggan from " & _
                "pelanggan order by nama_pelanggan", Conn)
            adapter.Fill(dt)
            textnama.Items.Clear()
            For i = 0 To dt.Rows.Count - 1
                textnama.Items.Add(dt.Rows(i)(0).ToString)
            Next i
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            Conn.Close()
        End Try
    End Sub

    Private Sub eksekusi(ByVal str1 As String)
        Dim sqlstr As String = str1
        Dim dt As New DataTable
        Try
            adapter = New MySqlDataAdapter(sqlstr, Conn)
            adapter.Fill(dt)
            'MsgBox(dt.Rows(0)(0).ToString, _
            '       MsgBoxStyle.Information, "Informasi")
        Catch ex As Exception
            'MsgBox(ex.Message.ToString, _
            '       MsgBoxStyle.Information, "Pesan")
        End Try
        Conn.Close()
    End Sub

    Private Sub textnama_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles textnama.SelectedIndexChanged
        Dim dt As New DataTable
        Try
            adapter = New MySqlDataAdapter( _
                "select kode_pelanggan from " & _
                "pelanggan where nama_pelanggan='" & _
                textnama.Text & "'", Conn)
            adapter.Fill(dt)
            textkd.Text = dt.Rows(0)(0).ToString
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            Conn.Close()
        End Try
    End Sub

    Private Sub DataGridView1_CellEndEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellEndEdit
        If DataGridView1.CurrentCell.ColumnIndex < 4 Then
            If DataGridView1.CurrentCell.ColumnIndex = 0 Then
                'MsgBox(DataGridView1.CurrentCell.Value)
                CariBuku(DataGridView1.CurrentCell.Value)
                SendKeys.Send("{up}")
                SendKeys.Send("{right}")
                SendKeys.Send("{right}")
                SendKeys.Send("{right}")
            Else
                'MsgBox(DataGridView1.CurrentCell.Value)
                SendKeys.Send("{up}")
                SendKeys.Send("{right}")
            End If
        End If
    End Sub

    Private Sub DataGridView1_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles DataGridView1.KeyPress
        If (e.KeyChar = Chr(13)) And _
            (DataGridView1.CurrentCell.ColumnIndex < 4) _
            Then
            SendKeys.Send("{up}")
            SendKeys.Send("{right}")
        End If
    End Sub

    Public Sub CariBuku(ByVal str As String)
        Dim dt As New DataTable
        Try
            adapter = New MySqlDataAdapter( _
                "select judul,harga_jual from buku where no_buku='" & _
                str & "'", Conn)
            adapter.Fill(dt)
            DataGridView1(1, DataGridView1.CurrentCell.RowIndex).Value = _
                dt.Rows(0)(0).ToString
            DataGridView1(2, DataGridView1.CurrentCell.RowIndex).Value = _
                dt.Rows(0)(1).ToString
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            Conn.Close()
        End Try
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        eksekusi("call insert_jual('" & _
                 textjual.Text & "','" & _
                 Format(dtp1.Value, "yyyy-MM-dd") & _
                 "','" & textkd.Text & "')")
        For i = 0 To DataGridView1.Rows.Count - 2
            eksekusi("call insert_djual('" & _
                 textjual.Text & "','" & _
                 DataGridView1(0, i).Value & "','" & _
                 DataGridView1(3, i).Value & "','" & _
                 DataGridView1(2, i).Value & "')")
        Next i

    End Sub


    Private Sub TabControl1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TabControl1.SelectedIndexChanged
        BindOrdersGrid()
    End Sub


    Private Sub DataGridView1_CellLeave(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellLeave
        texttotal.Text = caritotal(DataGridView1).ToString
        DataGridView1(4, DataGridView1.CurrentCell.RowIndex).Value = DataGridView1(3, DataGridView1.CurrentCell.RowIndex).Value * DataGridView1(2, DataGridView1.CurrentCell.RowIndex).Value
        If (DataGridView1.CurrentCell.ColumnIndex = 3) Then
            SendKeys.Send("{down}")
            SendKeys.Send("{left}")
            SendKeys.Send("{left}")
            SendKeys.Send("{left}")
            SendKeys.Send("{left}")
        End If

    End Sub

    Private Function caritotal(ByVal tabel As DataGridView) As Double
        Dim nilai As Double
        For i = 0 To tabel.Rows.Count - 1
            nilai = Val(texttotal.Text) + tabel(4, tabel.CurrentCell.RowIndex).Value
        Next i
        Return nilai
    End Function

End Class

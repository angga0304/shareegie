﻿Public Class frmMenuUtama

    Private Sub JualToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles JualToolStripMenuItem.Click
        Form1.Show()
    End Sub
End Class
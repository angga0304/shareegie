﻿Imports MySql.Data.MySqlClient
Module koneksi
    Public Conn As MySqlConnection
    Public Sub konek(ByVal a As String, _
                     ByVal b As String, _
                     ByVal c As String, _
                     ByVal d As String, _
                     ByVal e As String)
        Dim Connstr As String
        Connstr = "server=" & a & ";" _
            & "port=" & b & ";user=" & c & ";" _
            & "password='" & d & "';" _
            & "database=" & e
        Conn = New MySqlConnection(Connstr)
        Conn.Open()
    End Sub

End Module

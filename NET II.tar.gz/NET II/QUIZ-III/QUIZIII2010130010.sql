# SQL Manager 2005 Lite for MySQL 3.7.6.2
# ---------------------------------------
# Host     : localhost
# Port     : 3306
# Database : quiziii2010130010


SET FOREIGN_KEY_CHECKS=0;

DROP DATABASE IF EXISTS `quiziii2010130010`;

CREATE DATABASE `quiziii2010130010`
    CHARACTER SET 'latin1'
    COLLATE 'latin1_swedish_ci';

USE `quiziii2010130010`;

#
# Structure for the `buku` table : 
#

DROP TABLE IF EXISTS `buku`;

CREATE TABLE `buku` (
  `no_buku` char(10) NOT NULL,
  `no_barcode` char(10) NOT NULL,
  `judul` varchar(20) NOT NULL,
  `pengarang` varchar(20) default NULL,
  `kategori` varchar(20) default NULL,
  `harga_jual` double(15,3) default NULL,
  `harga_beli` double(15,3) default NULL,
  PRIMARY KEY  (`no_buku`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `pelanggan` table : 
#

DROP TABLE IF EXISTS `pelanggan`;

CREATE TABLE `pelanggan` (
  `kode_pelanggan` char(10) NOT NULL,
  `nama_pelanggan` varchar(20) NOT NULL,
  `alamat` varchar(30) default NULL,
  `telp` varchar(15) default NULL,
  `email` varchar(20) default NULL,
  `member_status` tinyint(1) default '0',
  `point` int(11) default '0',
  PRIMARY KEY  (`kode_pelanggan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `jual` table : 
#

DROP TABLE IF EXISTS `jual`;

CREATE TABLE `jual` (
  `no_jual` char(10) NOT NULL,
  `tanggal` date default NULL,
  `kode_pelanggan` char(10) default NULL,
  PRIMARY KEY  (`no_jual`),
  KEY `kode_pelanggan` (`kode_pelanggan`),
  CONSTRAINT `jual_fk` FOREIGN KEY (`kode_pelanggan`) REFERENCES `pelanggan` (`kode_pelanggan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `djual` table : 
#

DROP TABLE IF EXISTS `djual`;

CREATE TABLE `djual` (
  `no_jual` char(10) NOT NULL,
  `no_buku` char(10) NOT NULL,
  `harga` double(15,3) default '0.000',
  `banyak` int(11) default '0',
  PRIMARY KEY  (`no_jual`,`no_buku`),
  KEY `no_buku` (`no_buku`),
  KEY `no_jual` (`no_jual`),
  CONSTRAINT `djual_fk1` FOREIGN KEY (`no_jual`) REFERENCES `jual` (`no_jual`) ON UPDATE CASCADE,
  CONSTRAINT `djual_fk` FOREIGN KEY (`no_buku`) REFERENCES `buku` (`no_buku`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TRIGGER `djual_after_ins_tr` AFTER INSERT ON `djual`
  FOR EACH ROW
BEGIN
     update pelanggan set point = point+new.banyak
     where kode_pelanggan = (select distinct kode_pelanggan from jual j inner join djual d on(j.no_jual=new.no_jual));
END;

#
# Definition for the `insert_djual` procedure : 
#

DROP PROCEDURE IF EXISTS `insert_djual`;

CREATE PROCEDURE `insert_djual`(IN no CHAR(10), IN kd CHAR(5), IN byk INTEGER(11), IN hg INTEGER(11))
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY DEFINER
    COMMENT ''
BEGIN
     insert into djual
            values (no,kd,byk,hg);
END;

#
# Definition for the `insert_jual` procedure : 
#

DROP PROCEDURE IF EXISTS `insert_jual`;

CREATE PROCEDURE `insert_jual`(IN nom CHAR(10), IN tgl DATE, IN kd CHAR(10))
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY DEFINER
    COMMENT ''
BEGIN
declare kosong tinyint default 0;
declare n char(10);
declare cur cursor for select no_jual FROM
        jual where no_jual=nom;
declare continue handler FOR
        not found set kosong=1;

open cur;
fetch cur into n;
close cur;
if kosong =1 then
   insert into jual (no_jual,tanggal,kode_pelanggan)
   values (nom,tgl,kd);
   select'Data BERHASIL ditambahkan';
ELSE
update  jual set no_jual=nom,tanggal=tgl,kode_pelanggan=kd
   where no_jual=nom;
   select'Data BERHASIL diupdate';
 end if;

END;

#
# Definition for the `insert_pelanggan` procedure : 
#

DROP PROCEDURE IF EXISTS `insert_pelanggan`;

CREATE PROCEDURE `insert_pelanggan`(IN a CHAR(10), IN b VARCHAR(20), IN c VARCHAR(30), IN d VARCHAR(15), IN e VARCHAR(20), IN f TINYINT(1), IN g INTEGER(11))
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY DEFINER
    COMMENT ''
BEGIN
     declare continue handler for 1062
     select'data sudah ada!';
     insert into pelanggan values(a,b,c,d,e,f,g);
     select 'data berhasil ditambahkan!';
END;

#
# Definition for the `update_pelanggan` procedure : 
#

DROP PROCEDURE IF EXISTS `update_pelanggan`;

CREATE PROCEDURE `update_pelanggan`(IN a CHAR(10), IN b VARCHAR(20), IN c VARCHAR(30), IN d VARCHAR(15), IN e VARCHAR(20), IN f TINYINT(1), IN g INTEGER(11))
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY DEFINER
    COMMENT ''
BEGIN
     update pelanggan set nama_pelanggan = b, alamat=c, telp=d, email=e, member_status=f,point=g where kode_pelanggan =a;
     select 'data berhasil diubah';
END;

#
# Data for the `buku` table  (LIMIT 0,500)
#

INSERT INTO `buku` (`no_buku`, `no_barcode`, `judul`, `pengarang`, `kategori`, `harga_jual`, `harga_beli`) VALUES 
  ('BK001','5415341561','Harry Kejepret','Nyontya Meneer','Ilmiah',25000,29000),
  ('BK002','5645145615','Senandung Nyanyian S','Arya','Komedi',300000,320000);

COMMIT;

#
# Data for the `pelanggan` table  (LIMIT 0,500)
#

INSERT INTO `pelanggan` (`kode_pelanggan`, `nama_pelanggan`, `alamat`, `telp`, `email`, `member_status`, `point`) VALUES 
  ('2010130010','angga','otista 564','087821211103','angga@cute.com',1,15),
  ('2010130099','Ria','cimahi 56','087856415615','Ria@yahud.com',2,3);

COMMIT;

#
# Data for the `jual` table  (LIMIT 0,500)
#

INSERT INTO `jual` (`no_jual`, `tanggal`, `kode_pelanggan`) VALUES 
  ('03041992','2013-04-03','2010130010'),
  ('10041991','2013-04-29','2010130010'),
  ('10041992','2013-04-29','2010130099');

COMMIT;

#
# Data for the `djual` table  (LIMIT 0,500)
#

INSERT INTO `djual` (`no_jual`, `no_buku`, `harga`, `banyak`) VALUES 
  ('03041992','BK001',1,30000),
  ('03041992','BK002',56000,5),
  ('10041991','Bk001',35000,2),
  ('10041991','BK002',36500,5),
  ('10041992','BK001',56000,3);

COMMIT;


﻿Imports MySql.Data.MySqlClient
Public Class Form1
    Dim adapter As MySqlDataAdapter
    Dim readser As MySqlDataReader
    Dim cm As CurrencyManager
    Dim st As Boolean = False
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        konek()
        Dim sqlstr As String = "select * from pegawai"
        Dim dt As New DataTable
        Try
            adapter = New MySqlDataAdapter(sqlstr, conn)
            adapter.Fill(dt)
            DataGridView1.DataSource = dt
            cm = CType(Me.BindingContext(dt),  _
                CurrencyManager)
            DataGridView1.Columns(0).HeaderText = "Kode"
            DataGridView1.Columns(1).HeaderText = "Nama"
            DataGridView1.Columns(2).HeaderText = "Alamat"
            DataGridView1.Columns(3).HeaderText = "Email"
            DataGridView1.Columns(4).HeaderText = "Telpon"
            DataGridView1.Columns(5).HeaderText = "Tgl Lahir"
            DataGridView1.Columns(6).HeaderText = "Golongan"
            cm.Position = 0
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        cm.Position = 0
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        cm.Position = cm.Count - 1
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If cm.Position = 0 Then
            MsgBox("Awal Record...!!!", _
                   MsgBoxStyle.Information)
        Else
            cm.Position -= 1
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If cm.Position = cm.Count - 1 Then
            MsgBox("Akhir Record...!!!", _
                   MsgBoxStyle.Information)
        Else
            cm.Position += 1
        End If
    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        TextBox1.Text = ""
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        konek()
        Dim sqlstr As String = "select nama_pegawai,alamat," _
                               & "email,telp,tgl_lahir,golongan " _
                               & "from pegawai where kode_pegawai='" & TextBox1.Text & "'"
        Dim dt As New DataTable
        Try
            adapter = New MySqlDataAdapter(sqlstr, conn)
            adapter.Fill(dt)
            TextBox2.Text = dt.Rows(0)(0).ToString
            TextBox3.Text = dt.Rows(0)(1).ToString
            TextBox4.Text = dt.Rows(0)(2).ToString
            TextBox5.Text = dt.Rows(0)(3).ToString
            'DateTimePicker1.Value = dt.Rows(0)(4)
            TextBox6.Text = dt.Rows(0)(5).ToString
            st = True
        Catch ex As Exception
            'MessageBox.Show(ex.Message)
            TextBox2.Text = ""
            TextBox3.Text = ""
            TextBox4.Text = ""
            TextBox5.Text = ""
            TextBox6.Text = ""
            st = False
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Dim cmd As New MySqlCommand

        cmd.CommandType = CommandType.Text
        cmd.CommandText = ("delete from pegawai where kode_pegawai='" & TextBox1.Text & "'")
        konek()
        cmd.Connection = conn
        Try
            cmd.ExecuteNonQuery()
            MsgBox("Data Telah Terhapus !", _
                   MsgBoxStyle.Information, "Informasi")
            conn.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, _
                   MsgBoxStyle.Information, "Pesan")
        End Try
        Form1_Load(Me, e)
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Dim cmd As New MySqlCommand

        cmd.CommandType = CommandType.Text
        cmd.CommandText = ("insert into pegawai values('" _
                           & TextBox1.Text & "','" & TextBox2.Text & "'," _
                           & "'" & TextBox3.Text & "','" & TextBox4.Text & "'," _
                           & "'" & TextBox5.Text & "','" & Format(DateTimePicker1.Value, "yyyy-MM-dd") & "'," _
                           & TextBox6.Text & ")")
        konek()
        cmd.Connection = conn
        Try
            cmd.ExecuteNonQuery()
            MsgBox("Data Telah Tersimpan !", _
                   MsgBoxStyle.Information, "Informasi")
            conn.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, _
                   MsgBoxStyle.Information, "Pesan")
        End Try
        Form1_Load(Me, e)
    End Sub
End Class

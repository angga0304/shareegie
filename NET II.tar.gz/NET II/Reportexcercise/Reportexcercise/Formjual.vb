﻿Public Class Formjual

    Private Sub Formjual_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'net_xiiiDataSet.jual' table. You can move, or remove it, as needed.
        
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.jualTableAdapter.Fill(Me.net_xiiiDataSet.jual, DateTimePicker1.Value,DateTimePicker2.Value)

        Me.ReportViewer1.RefreshReport()
    End Sub
End Class
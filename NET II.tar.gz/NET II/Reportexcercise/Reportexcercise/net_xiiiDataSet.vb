﻿Partial Class net_xiiiDataSet
End Class

Namespace net_xiiiDataSetTableAdapters
    
    Partial Public Class barangTableAdapter
    End Class
End Namespace

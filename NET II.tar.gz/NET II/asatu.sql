# SQL Manager 2005 Lite for MySQL 3.7.6.2
# ---------------------------------------
# Host     : localhost
# Port     : 3306
# Database : asatu


SET FOREIGN_KEY_CHECKS=0;

DROP DATABASE IF EXISTS `asatu`;

CREATE DATABASE `asatu`
    CHARACTER SET 'latin1'
    COLLATE 'latin1_swedish_ci';

USE `asatu`;

#
# Structure for the `animal` table : 
#

DROP TABLE IF EXISTS `animal`;

CREATE TABLE `animal` (
  `AnimalID` int(11) NOT NULL,
  `Name` varchar(45) default NULL,
  `Category` varchar(45) default NULL,
  `Breed` varchar(45) default NULL,
  `DateReborn` date NOT NULL,
  `Gender` varchar(45) default NULL,
  `Registered` varchar(45) default NULL,
  `Color` varchar(45) default NULL,
  `ListPrice` decimal(6,2) default NULL,
  PRIMARY KEY  (`AnimalID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `city` table : 
#

DROP TABLE IF EXISTS `city`;

CREATE TABLE `city` (
  `CityID` int(11) NOT NULL,
  `ZipCode` varchar(45) default NULL,
  `City` varchar(45) default NULL,
  `State` varchar(45) default NULL,
  `AreaCode` varchar(45) default NULL,
  `Population1990` int(11) default NULL,
  `Population1980` int(11) default NULL,
  `Country` varchar(45) default NULL,
  `Latitude` double(15,3) default NULL,
  `Longitude` double(15,3) default NULL,
  PRIMARY KEY  (`CityID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `supplier` table : 
#

DROP TABLE IF EXISTS `supplier`;

CREATE TABLE `supplier` (
  `SupplierID` int(11) NOT NULL,
  `Name` varchar(45) default NULL,
  `ContactName` varchar(45) default NULL,
  `Phone` varchar(45) default NULL,
  `Address` varchar(45) default NULL,
  `ZipCode` varchar(45) default NULL,
  `CityID` int(11) default NULL,
  PRIMARY KEY  (`SupplierID`),
  KEY `CityID` (`CityID`),
  CONSTRAINT `supplier_city_fk` FOREIGN KEY (`CityID`) REFERENCES `city` (`CityID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `employee` table : 
#

DROP TABLE IF EXISTS `employee`;

CREATE TABLE `employee` (
  `EmployeeID` int(11) NOT NULL,
  `LastName` varchar(45) default NULL,
  `FirstName` varchar(45) default NULL,
  `Phone` varchar(45) default NULL,
  `Address` varchar(45) default NULL,
  `ZipCode` varchar(45) default NULL,
  `TaxPayerID` varchar(45) default NULL,
  `DateHired` date NOT NULL,
  `DateReleased` date NOT NULL,
  `ManagerID` int(11) default NULL,
  `EmployeeLevel` int(11) default NULL,
  `Title` varchar(45) default NULL,
  `CityID` int(11) default NULL,
  PRIMARY KEY  (`EmployeeID`),
  KEY `CityID` (`CityID`),
  CONSTRAINT `employee_city_fk` FOREIGN KEY (`CityID`) REFERENCES `city` (`CityID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `animalorder` table : 
#

DROP TABLE IF EXISTS `animalorder`;

CREATE TABLE `animalorder` (
  `OrderID` int(11) NOT NULL,
  `OrderDate` date NOT NULL,
  `ReceiveDate` date NOT NULL,
  `SupplierID` int(11) default NULL,
  `ShippingCost` decimal(6,2) default NULL,
  `EmployeeID` int(11) default NULL,
  PRIMARY KEY  (`OrderID`),
  KEY `EmployeeID` (`EmployeeID`),
  KEY `SupplierID` (`SupplierID`),
  CONSTRAINT `animalorder_supplier_fk` FOREIGN KEY (`SupplierID`) REFERENCES `supplier` (`SupplierID`) ON UPDATE CASCADE,
  CONSTRAINT `animalorder_employee_fk` FOREIGN KEY (`EmployeeID`) REFERENCES `employee` (`EmployeeID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `animalorderitem` table : 
#

DROP TABLE IF EXISTS `animalorderitem`;

CREATE TABLE `animalorderitem` (
  `OrderID` int(11) NOT NULL,
  `AnimalID` int(11) NOT NULL,
  `Cost` decimal(6,2) default NULL,
  PRIMARY KEY  (`OrderID`,`AnimalID`),
  KEY `OrderID` (`OrderID`),
  KEY `AnimalID` (`AnimalID`),
  CONSTRAINT `animalorderitem_animal_fk` FOREIGN KEY (`AnimalID`) REFERENCES `animal` (`AnimalID`) ON UPDATE CASCADE,
  CONSTRAINT `animalorderitem_animalorder_fk` FOREIGN KEY (`OrderID`) REFERENCES `animalorder` (`OrderID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `customer` table : 
#

DROP TABLE IF EXISTS `customer`;

CREATE TABLE `customer` (
  `CustomerID` int(11) NOT NULL,
  `Phone` varchar(45) default NULL,
  `FirstName` varchar(45) default NULL,
  `LastName` varchar(45) default NULL,
  `Address` varchar(45) default NULL,
  `ZipCode` varchar(45) default NULL,
  `CityID` int(11) default NULL,
  PRIMARY KEY  (`CustomerID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `merchandise` table : 
#

DROP TABLE IF EXISTS `merchandise`;

CREATE TABLE `merchandise` (
  `ItemID` int(11) NOT NULL,
  `Description` varchar(45) default NULL,
  `QuantityOnHand` int(11) default NULL,
  `ListPrice` decimal(6,2) default NULL,
  `Category` varchar(45) default NULL,
  PRIMARY KEY  (`ItemID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `merchandiseorder` table : 
#

DROP TABLE IF EXISTS `merchandiseorder`;

CREATE TABLE `merchandiseorder` (
  `PONumber` int(11) NOT NULL,
  `OrderDate` date NOT NULL,
  `ReceiveDate` date NOT NULL,
  `SupplierID` int(11) default NULL,
  `EmployeeID` int(11) default NULL,
  `ShippingCost` decimal(6,2) default NULL,
  PRIMARY KEY  (`PONumber`),
  KEY `SupplierID` (`SupplierID`),
  KEY `EmployeeID` (`EmployeeID`),
  CONSTRAINT `merchandiseorder_employee_fk` FOREIGN KEY (`EmployeeID`) REFERENCES `employee` (`EmployeeID`) ON UPDATE CASCADE,
  CONSTRAINT `merchandiseorder_supplier_fk` FOREIGN KEY (`SupplierID`) REFERENCES `supplier` (`SupplierID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `orderitem` table : 
#

DROP TABLE IF EXISTS `orderitem`;

CREATE TABLE `orderitem` (
  `PONumber` int(11) NOT NULL,
  `ItemID` int(11) NOT NULL,
  `Quantity` int(11) default NULL,
  `Cost` double(6,2) default NULL,
  PRIMARY KEY  (`PONumber`,`ItemID`),
  KEY `ItemID` (`ItemID`),
  KEY `PONumber` (`PONumber`),
  CONSTRAINT `orderitem_ponumber_fk` FOREIGN KEY (`PONumber`) REFERENCES `merchandiseorder` (`PONumber`) ON UPDATE CASCADE,
  CONSTRAINT `orderitem_merchandise_fk` FOREIGN KEY (`ItemID`) REFERENCES `merchandise` (`ItemID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `sale` table : 
#

DROP TABLE IF EXISTS `sale`;

CREATE TABLE `sale` (
  `SaleID` int(11) NOT NULL,
  `SaleDate` date NOT NULL,
  `EmployeeID` int(11) default NULL,
  `CustomerID` int(11) default NULL,
  `SalexTax` decimal(6,2) default NULL,
  PRIMARY KEY  (`SaleID`),
  KEY `sale_customer_fk` (`CustomerID`),
  KEY `EmployeeID` (`EmployeeID`),
  CONSTRAINT `sale_employee_fk` FOREIGN KEY (`EmployeeID`) REFERENCES `employee` (`EmployeeID`) ON UPDATE CASCADE,
  CONSTRAINT `sale_customer_fk` FOREIGN KEY (`CustomerID`) REFERENCES `customer` (`CustomerID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `saleanimal` table : 
#

DROP TABLE IF EXISTS `saleanimal`;

CREATE TABLE `saleanimal` (
  `SaleID` int(11) NOT NULL,
  `AnimalID` int(11) NOT NULL,
  `SalePrice` decimal(6,2) default NULL,
  PRIMARY KEY  (`SaleID`,`AnimalID`),
  KEY `SaleID` (`SaleID`),
  KEY `AnimalID` (`AnimalID`),
  CONSTRAINT `saleanimal_animal_fk` FOREIGN KEY (`AnimalID`) REFERENCES `animal` (`AnimalID`) ON UPDATE CASCADE,
  CONSTRAINT `saleanimal_sale_fk` FOREIGN KEY (`SaleID`) REFERENCES `sale` (`SaleID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 CHECKSUM=1;

#
# Structure for the `saleitem` table : 
#

DROP TABLE IF EXISTS `saleitem`;

CREATE TABLE `saleitem` (
  `SaleID` int(11) NOT NULL,
  `ItemID` int(11) NOT NULL,
  `Quantity` int(11) default NULL,
  `SalePrice` double(6,2) default NULL,
  PRIMARY KEY  (`SaleID`,`ItemID`),
  KEY `SaleID` (`SaleID`),
  KEY `ItemID` (`ItemID`),
  CONSTRAINT `saleitem_merchandise_fk` FOREIGN KEY (`ItemID`) REFERENCES `merchandise` (`ItemID`) ON UPDATE CASCADE,
  CONSTRAINT `saleitem_sale_fk` FOREIGN KEY (`SaleID`) REFERENCES `sale` (`SaleID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for the `city` table  (LIMIT 0,500)
#

INSERT INTO `city` (`CityID`, `ZipCode`, `City`, `State`, `AreaCode`, `Population1990`, `Population1980`, `Country`, `Latitude`, `Longitude`) VALUES 
  (12,'12','bdg','idn','33',100,101,'indo',2,4);

COMMIT;


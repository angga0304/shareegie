# SQL Manager 2005 Lite for MySQL 3.7.6.2
# ---------------------------------------
# Host     : localhost
# Port     : 3306
# Database : bebasapaaja


SET FOREIGN_KEY_CHECKS=0;

DROP DATABASE IF EXISTS `bebasapaaja`;

CREATE DATABASE `bebasapaaja`
    CHARACTER SET 'latin1'
    COLLATE 'latin1_swedish_ci';

USE `bebasapaaja`;

#
# Structure for the `penjualan` table : 
#

DROP TABLE IF EXISTS `penjualan`;

CREATE TABLE `penjualan` (
  `no_karyawan` tinyint(4) NOT NULL,
  `tanggal` date NOT NULL,
  `jml_penjualan` decimal(6,2) NOT NULL,
  `kode_barang` int(11) NOT NULL,
  PRIMARY KEY  (`no_karyawan`,`tanggal`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TRIGGER `penjualan_after_ins_tr` AFTER INSERT ON `penjualan`
  FOR EACH ROW
BEGIN
     UPDATE performance set total_penjualan= total_penjualan + new.jml_penjualan
     where no_karyawan = new.no_karyawan;
     update performance set rata2_penjualan = total_penjualan / (select datediff(max(tanggal),min(tanggal))+1 from penjualan where no_karyawan=new.no_karyawan)
     where no_karyawan=new.no_karyawan;
     /*update performance set rata2_penjualan = total_penjualan / (select count(tanggal) from penjualan where no_karyawan=new.no_karyawan)
     where no_karyawan=new.no_karyawan;*/
END;

CREATE TRIGGER `penjualan_after_upd_tr` AFTER UPDATE ON `penjualan`
  FOR EACH ROW
BEGIN
     UPDATE performance set total_penjualan= total_penjualan -old.jml_penjualan+ new.jml_penjualan
     where no_karyawan = new.no_karyawan;
     update performance set rata2_penjualan = total_penjualan / (select count(tanggal) from penjualan where no_karyawan=new.no_karyawan)
     where no_karyawan=new.no_karyawan;
END;

CREATE TRIGGER `penjualan_before_del_tr` BEFORE DELETE ON `penjualan`
  FOR EACH ROW
BEGIN
     if((select count(tanggal) from penjualan where no_karyawan=old.no_karyawan)<=1) then
     update performance set total_penjualan=0,rata2_penjualan=0 where no_karyawan=old.no_karyawan;
     else
     UPDATE performance set total_penjualan= total_penjualan -old.jml_penjualan
     where no_karyawan = old.no_karyawan;
     update performance set rata2_penjualan = total_penjualan / (select count(tanggal)-1 from penjualan where no_karyawan=old.no_karyawan)
     where no_karyawan=old.no_karyawan;
     end if;
END;

#
# Structure for the `performance` table : 
#

DROP TABLE IF EXISTS `performance`;

CREATE TABLE `performance` (
  `no_karyawan` tinyint(4) NOT NULL,
  `nama_karyawan` varchar(25) NOT NULL,
  `total_penjualan` decimal(6,2) NOT NULL,
  `rata2_penjualan` decimal(6,2) NOT NULL,
  PRIMARY KEY  (`no_karyawan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for the `performance` table  (LIMIT 0,500)
#

INSERT INTO `performance` (`no_karyawan`, `nama_karyawan`, `total_penjualan`, `rata2_penjualan`) VALUES 
  (1,'angga',0,0);

COMMIT;


# SQL Manager 2005 Lite for MySQL 3.7.6.2
# ---------------------------------------
# Host     : localhost
# Port     : 3306
# Database : bsatu


SET FOREIGN_KEY_CHECKS=0;

DROP DATABASE IF EXISTS `bsatu`;

CREATE DATABASE `bsatu`
    CHARACTER SET 'latin1'
    COLLATE 'latin1_swedish_ci';

USE `bsatu`;

#
# Structure for the `animal` table : 
#

DROP TABLE IF EXISTS `animal`;

CREATE TABLE `animal` (
  `animalid` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `category` varchar(45) default NULL,
  `breed` varchar(45) default NULL,
  `dateborn` date default NULL,
  `gender` varchar(45) NOT NULL,
  `registered` varchar(45) default NULL,
  `color` varchar(45) default NULL,
  `listprice` decimal(6,2) default NULL,
  PRIMARY KEY  (`animalid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `city` table : 
#

DROP TABLE IF EXISTS `city`;

CREATE TABLE `city` (
  `cityid` int(11) NOT NULL,
  `zipcode` varchar(45) default NULL,
  `city` varchar(45) NOT NULL,
  `state` varchar(45) default NULL,
  `areacode` varchar(45) default NULL,
  `population1990` int(11) default NULL,
  `population1980` int(11) default NULL,
  `country` varchar(45) default NULL,
  `latitude` double(15,3) default NULL,
  `longitude` double(15,3) default NULL,
  PRIMARY KEY  (`cityid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `employee` table : 
#

DROP TABLE IF EXISTS `employee`;

CREATE TABLE `employee` (
  `employeeid` int(11) NOT NULL,
  `lastname` varchar(45) default NULL,
  `firstname` varchar(45) NOT NULL,
  `phone` varchar(45) default NULL,
  `address` varchar(45) default NULL,
  `zipcode` varchar(45) default NULL,
  `cityid` int(11) default NULL,
  `taxpayerid` varchar(45) default NULL,
  `datehired` date default NULL,
  `datereleased` date default NULL,
  `managerid` int(11) default NULL,
  `employeelevel` int(11) default NULL,
  `title` varchar(45) default NULL,
  PRIMARY KEY  (`employeeid`),
  KEY `cityid` (`cityid`),
  CONSTRAINT `employee_fk` FOREIGN KEY (`cityid`) REFERENCES `city` (`cityid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `supplier` table : 
#

DROP TABLE IF EXISTS `supplier`;

CREATE TABLE `supplier` (
  `supplierid` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `contactname` varchar(45) default NULL,
  `phone` varchar(45) default NULL,
  `address` varchar(45) default NULL,
  `zipcode` varchar(45) default NULL,
  `cityid` int(11) default NULL,
  PRIMARY KEY  (`supplierid`),
  KEY `cityid` (`cityid`),
  CONSTRAINT `supplier_fk` FOREIGN KEY (`cityid`) REFERENCES `city` (`cityid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `animalorder` table : 
#

DROP TABLE IF EXISTS `animalorder`;

CREATE TABLE `animalorder` (
  `orderid` int(11) NOT NULL,
  `orderdate` date NOT NULL,
  `receivedate` date default NULL,
  `supplierid` int(11) default NULL,
  `shippingcost` decimal(6,2) default NULL,
  `employeeid` int(11) default NULL,
  PRIMARY KEY  (`orderid`),
  KEY `supplierid` (`supplierid`),
  KEY `employeeid` (`employeeid`),
  CONSTRAINT `animalorder_fk1` FOREIGN KEY (`employeeid`) REFERENCES `employee` (`employeeid`) ON UPDATE CASCADE,
  CONSTRAINT `animalorder_fk` FOREIGN KEY (`supplierid`) REFERENCES `supplier` (`supplierid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `animalorderitem` table : 
#

DROP TABLE IF EXISTS `animalorderitem`;

CREATE TABLE `animalorderitem` (
  `orderid` int(11) NOT NULL,
  `animalid` int(11) NOT NULL,
  `cost` decimal(6,2) default NULL,
  PRIMARY KEY  (`orderid`,`animalid`),
  KEY `orderid` (`orderid`),
  KEY `animalid` (`animalid`),
  CONSTRAINT `animalorderitem_fk1` FOREIGN KEY (`animalid`) REFERENCES `animal` (`animalid`) ON UPDATE CASCADE,
  CONSTRAINT `animalorderitem_fk` FOREIGN KEY (`orderid`) REFERENCES `animalorder` (`orderid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `barang` table : 
#

DROP TABLE IF EXISTS `barang`;

CREATE TABLE `barang` (
  `kode_barang` char(5) NOT NULL,
  `nama_barang` varchar(20) NOT NULL,
  `stok` int(11) default '0',
  PRIMARY KEY  (`kode_barang`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `customer` table : 
#

DROP TABLE IF EXISTS `customer`;

CREATE TABLE `customer` (
  `CustomerID` int(11) NOT NULL,
  `phone` varchar(45) default NULL,
  `firstname` varchar(45) NOT NULL,
  `lastname` varchar(45) default NULL,
  `address` varchar(45) default NULL,
  `zipcode` varchar(45) default NULL,
  `cityid` int(11) default NULL,
  PRIMARY KEY  (`CustomerID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `mahasiswa` table : 
#

DROP TABLE IF EXISTS `mahasiswa`;

CREATE TABLE `mahasiswa` (
  `npm` char(10) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `jk` tinyint(1) default '1',
  `email` varchar(50) default '-',
  PRIMARY KEY  (`npm`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `merchandise` table : 
#

DROP TABLE IF EXISTS `merchandise`;

CREATE TABLE `merchandise` (
  `itemid` int(11) NOT NULL,
  `description` varchar(45) default NULL,
  `quantityonhand` int(11) default NULL,
  `listprice` decimal(6,2) default NULL,
  `category` varchar(45) default NULL,
  PRIMARY KEY  (`itemid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `merchandiseorder` table : 
#

DROP TABLE IF EXISTS `merchandiseorder`;

CREATE TABLE `merchandiseorder` (
  `ponumber` int(11) NOT NULL,
  `orderdate` date NOT NULL,
  `receivedate` date default NULL,
  `supplierid` int(11) default NULL,
  `employeeid` int(11) default NULL,
  `shippingcost` decimal(6,2) default NULL,
  PRIMARY KEY  (`ponumber`),
  KEY `employeeid` (`employeeid`),
  KEY `supplierid` (`supplierid`),
  CONSTRAINT `merchandiseorder_fk1` FOREIGN KEY (`supplierid`) REFERENCES `supplier` (`supplierid`) ON UPDATE CASCADE,
  CONSTRAINT `merchandiseorder_fk` FOREIGN KEY (`employeeid`) REFERENCES `employee` (`employeeid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `orderitem` table : 
#

DROP TABLE IF EXISTS `orderitem`;

CREATE TABLE `orderitem` (
  `ponumber` int(11) NOT NULL,
  `itemid` int(11) NOT NULL,
  `quantity` int(11) default NULL,
  `cost` double(6,2) default NULL,
  PRIMARY KEY  (`ponumber`,`itemid`),
  KEY `ponumber` (`ponumber`),
  KEY `itemid` (`itemid`),
  CONSTRAINT `orderitem_fk1` FOREIGN KEY (`itemid`) REFERENCES `merchandise` (`itemid`) ON UPDATE CASCADE,
  CONSTRAINT `orderitem_fk` FOREIGN KEY (`ponumber`) REFERENCES `merchandiseorder` (`ponumber`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `sale` table : 
#

DROP TABLE IF EXISTS `sale`;

CREATE TABLE `sale` (
  `saleid` int(11) NOT NULL,
  `saledate` date NOT NULL,
  `employeeid` int(11) default NULL,
  `customerid` int(11) default NULL,
  `salestax` decimal(6,2) default NULL,
  PRIMARY KEY  (`saleid`),
  KEY `customerid` (`customerid`),
  KEY `employeeid` (`employeeid`),
  CONSTRAINT `sale_fk1` FOREIGN KEY (`employeeid`) REFERENCES `employee` (`employeeid`) ON UPDATE CASCADE,
  CONSTRAINT `sale_fk` FOREIGN KEY (`customerid`) REFERENCES `customer` (`CustomerID`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `saleanimal` table : 
#

DROP TABLE IF EXISTS `saleanimal`;

CREATE TABLE `saleanimal` (
  `saleid` int(11) NOT NULL,
  `animalid` int(11) NOT NULL,
  `saleprice` decimal(6,2) default NULL,
  PRIMARY KEY  (`saleid`,`animalid`),
  KEY `saleid` (`saleid`),
  KEY `animalid` (`animalid`),
  CONSTRAINT `saleanimal_fk1` FOREIGN KEY (`animalid`) REFERENCES `animal` (`animalid`) ON UPDATE CASCADE,
  CONSTRAINT `saleanimal_fk` FOREIGN KEY (`saleid`) REFERENCES `sale` (`saleid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `saleitem` table : 
#

DROP TABLE IF EXISTS `saleitem`;

CREATE TABLE `saleitem` (
  `saleid` int(11) NOT NULL,
  `itemid` int(11) NOT NULL,
  `quantity` int(11) default NULL,
  `saleprice` double(15,3) default NULL,
  PRIMARY KEY  (`saleid`,`itemid`),
  KEY `saleid` (`saleid`),
  KEY `itemid` (`itemid`),
  CONSTRAINT `saleitem_fk1` FOREIGN KEY (`itemid`) REFERENCES `merchandise` (`itemid`) ON UPDATE CASCADE,
  CONSTRAINT `saleitem_fk` FOREIGN KEY (`saleid`) REFERENCES `sale` (`saleid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Definition for the `new_proc` procedure : 
#

DROP PROCEDURE IF EXISTS `new_proc`;

CREATE PROCEDURE `new_proc`(IN a INTEGER(11), IN b VARCHAR(45), IN c VARCHAR(45), IN d VARCHAR(45), IN e DATE, IN f VARCHAR(45), IN g VARCHAR(45), IN h VARCHAR(45), IN i SMALLINT)
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY DEFINER
    COMMENT ''
BEGIN
     declare continue handler for 1062
     select'data sudah ada!';
     insert into animal values(a,b,c,d,e,f,g,h,i);
     select'Data berhasil ditambahkan!';
END;

#
# Definition for the `kode_baru` function : 
#

DROP FUNCTION IF EXISTS `kode_baru`;

CREATE FUNCTION `kode_baru`()
    RETURNS int(11)
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY DEFINER
    COMMENT ''
BEGIN
     declare n INTEGER(11);
     declare cur cursor for select max(animalid) from animal;
     open cur;
     fetch cur into n;
     close cur;

     if n is null then
        set n = 1;
     else
         set n = n+1;
         end if;

     return(n);
end;

#
# Definition for the `npm_baru` function : 
#

DROP FUNCTION IF EXISTS `npm_baru`;

CREATE FUNCTION `npm_baru`()
    RETURNS char(10)
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY DEFINER
    COMMENT ''
BEGIN
     declare n char(10);
     declare cur cursor for select max(npm) from mahasiswa;
     
     open cur;
     fetch cur into n;
     close cur;
     
     if n is null then
        set n = concat(year(now()),'130001');
     else
         set n = n+1;
         end if;
         
     return(n);
end;

#
# Data for the `animal` table  (LIMIT 0,500)
#

INSERT INTO `animal` (`animalid`, `name`, `category`, `breed`, `dateborn`, `gender`, `registered`, `color`, `listprice`) VALUES 
  (1,'Asu','anjing!','burhan','1899-12-14','jantan','sah','putih galau',5000),
  (2,'Cien2','Primata','Cihuahua','1992-07-14','Abstrak','NO','Hitam Manis',3500);

COMMIT;

#
# Data for the `city` table  (LIMIT 0,500)
#

INSERT INTO `city` (`cityid`, `zipcode`, `city`, `state`, `areacode`, `population1990`, `population1980`, `country`, `latitude`, `longitude`) VALUES 
  (45,'4356','bandung','jawabarat','7463',7454,23765,'indonesia',11,11);

COMMIT;

#
# Data for the `employee` table  (LIMIT 0,500)
#

INSERT INTO `employee` (`employeeid`, `lastname`, `firstname`, `phone`, `address`, `zipcode`, `cityid`, `taxpayerid`, `datehired`, `datereleased`, `managerid`, `employeelevel`, `title`) VALUES 
  (1,'tamara','angga','5221479','sebelah tegalega','42024',45,'2','2013-01-09','2013-01-10',2,7,'sang penakluk');

COMMIT;

#
# Data for the `supplier` table  (LIMIT 0,500)
#

INSERT INTO `supplier` (`supplierid`, `name`, `contactname`, `phone`, `address`, `zipcode`, `cityid`) VALUES 
  (1,'joko','jokocute','673423','uigfd','7865',45);

COMMIT;

#
# Data for the `animalorder` table  (LIMIT 0,500)
#

INSERT INTO `animalorder` (`orderid`, `orderdate`, `receivedate`, `supplierid`, `shippingcost`, `employeeid`) VALUES 
  (1,'1899-12-05','1899-12-06',1,500,1);

COMMIT;

#
# Data for the `animalorderitem` table  (LIMIT 0,500)
#

INSERT INTO `animalorderitem` (`orderid`, `animalid`, `cost`) VALUES 
  (1,1,1400);

COMMIT;

#
# Data for the `customer` table  (LIMIT 0,500)
#

INSERT INTO `customer` (`CustomerID`, `phone`, `firstname`, `lastname`, `address`, `zipcode`, `cityid`) VALUES 
  (3,'5230784','yovan','marcel','pasundan','87438',45);

COMMIT;

#
# Data for the `mahasiswa` table  (LIMIT 0,500)
#

INSERT INTO `mahasiswa` (`npm`, `nama`, `jk`, `email`) VALUES 
  ('2013130055','Anwar',1,'anwar@likmi.ac.id');

COMMIT;

#
# Data for the `merchandise` table  (LIMIT 0,500)
#

INSERT INTO `merchandise` (`itemid`, `description`, `quantityonhand`, `listprice`, `category`) VALUES 
  (1,'remahkayu',3,5000,'tempat');

COMMIT;

#
# Data for the `merchandiseorder` table  (LIMIT 0,500)
#

INSERT INTO `merchandiseorder` (`ponumber`, `orderdate`, `receivedate`, `supplierid`, `employeeid`, `shippingcost`) VALUES 
  (1,'1899-12-05','1899-12-06',1,1,500);

COMMIT;

#
# Data for the `orderitem` table  (LIMIT 0,500)
#

INSERT INTO `orderitem` (`ponumber`, `itemid`, `quantity`, `cost`) VALUES 
  (1,1,23,568);

COMMIT;

#
# Data for the `sale` table  (LIMIT 0,500)
#

INSERT INTO `sale` (`saleid`, `saledate`, `employeeid`, `customerid`, `salestax`) VALUES 
  (1,'2013-01-09',1,3,2);

COMMIT;

#
# Data for the `saleanimal` table  (LIMIT 0,500)
#

INSERT INTO `saleanimal` (`saleid`, `animalid`, `saleprice`) VALUES 
  (1,1,500);

COMMIT;

#
# Data for the `saleitem` table  (LIMIT 0,500)
#

INSERT INTO `saleitem` (`saleid`, `itemid`, `quantity`, `saleprice`) VALUES 
  (1,1,1,500);

COMMIT;


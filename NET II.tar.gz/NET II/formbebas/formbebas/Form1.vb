﻿Imports MySql.Data.MySqlClient
Public Class Form1
    Dim adapter As MySqlDataAdapter
    Dim reader As MySqlDataReader
    Dim CM As CurrencyManager
    Dim st As Boolean = False
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim str As String = "call tambah('" & TextBox10.Text & "','" _
                            & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" _
                            & TextBox4.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "','" _
                            & TextBox7.Text & "','" & TextBox8.Text & "','" & Format(DateTimePicker1.Value, "yyyy-MM-dd") & "');"
        Run_SQL(str)
        Form1_Load(Me, e)
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        konek()
        Dim sqlstr As String = "select nama,alamat,kota,propinsi,kodepos,negara,email,kredit,tgl from orang"
        Dim dt As New DataTable
        Try
            adapter = New MySqlDataAdapter(sqlstr, Conn)
            adapter.Fill(dt)
            DataGridView1.DataSource = dt
            'Mendapatkan BindingManagerBase
            CM = CType(Me.BindingContext(dt),  _
                CurrencyManager)
            DataGridView1.Columns(0).HeaderText = "Nama"
            DataGridView1.Columns(1).HeaderText = "Alamat"
            DataGridView1.Columns(2).HeaderText = "kota"
            DataGridView1.Columns(3).HeaderText = "Propinsi"
            DataGridView1.Columns(4).HeaderText = "KodePos"
            DataGridView1.Columns(5).HeaderText = "Negara"
            DataGridView1.Columns(6).HeaderText = "Email"
            DataGridView1.Columns(7).HeaderText = "Kertu Kredit"
            DataGridView1.Columns(8).HeaderText = "Tenggal exp"
            'Menetapkan posisi awal
            CM.Position = 0
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            Conn.Close()
        End Try
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub TextBox10_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox10.TextChanged
        konek()
        Dim sqlstr As String = "select nama,alamat,kota,propinsi,kodepos,negara,email,kredit,tgl from orang where nomor = '" & TextBox10.Text & "'"
        Dim dt As New DataTable
        Try
            adapter = New MySqlDataAdapter(sqlstr, Conn)
            adapter.Fill(dt)
            TextBox1.Text = dt.Rows(0)(0).ToString
            TextBox2.Text = dt.Rows(0)(1).ToString
            TextBox3.Text = dt.Rows(0)(2).ToString
            TextBox4.Text = dt.Rows(0)(3).ToString
            TextBox5.Text = dt.Rows(0)(4).ToString
            TextBox6.Text = dt.Rows(0)(5).ToString
            TextBox7.Text = dt.Rows(0)(6).ToString
            TextBox8.Text = dt.Rows(0)(7).ToString
            DateTimePicker1.Value = dt.Rows(0)(8)
        Catch ex As Exception
            'MessageBox.Show(ex.Message)
            TextBox1.Text = ""
            TextBox2.Text = ""
            TextBox3.Text = ""
            TextBox4.Text = ""
            TextBox5.Text = ""
            TextBox6.Text = ""
            TextBox7.Text = ""
            TextBox8.Text = ""
            st = False
        Finally
            Conn.Close()
        End Try
    End Sub
    Private Sub Run_SQL(ByVal perintah As String)
        Dim dt As New DataTable
        Try
            adapter = New MySqlDataAdapter(perintah, Conn)
            adapter.Fill(dt)
            MsgBox(dt.Rows(0)(0).ToString, _
                   MsgBoxStyle.Information)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            Conn.Close()
        End Try
        'frmanimal_Load(Me, e)
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim str As String = "call hapusdata('" & TextBox10.Text & "')"
        Run_SQL(str)
        Form1_Load(Me, e)
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim dt As New DataTable
        Try
            adapter = New MySqlDataAdapter("select kodebaru()", Conn)
            adapter.Fill(dt)
            TextBox10.Text = dt.Rows(0)(0).ToString
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            Conn.Close()
        End Try
    End Sub
End Class

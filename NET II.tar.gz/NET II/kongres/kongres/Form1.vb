﻿Imports MySql.Data.MySqlClient
Public Class Form1

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub

    Private Sub Label5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        String perintah = "tambah_data('"& TextBox1.Text &"','"&  &"','','','','','','','','')"
    End Sub
    Private Sub Run_SQL(ByVal perintah As String, ByVal msg As String)
        Dim cmd As New MySqlCommand
        cmd.CommandType = CommandType.Text
        cmd.CommandText = (perintah)
        konek()
        cmd.Connection = Conn
        Try
            cmd.ExecuteNonQuery()
            MsgBox(msg, MsgBoxStyle.Information, "Informasi")
            Conn.Close()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, _
                   MsgBoxStyle.Information, "Pesan")
        End Try
    End Sub
End Class

# SQL Manager 2005 Lite for MySQL 3.7.6.2
# ---------------------------------------
# Host     : localhost
# Port     : 3306
# Database : latihanuts2010130010


SET FOREIGN_KEY_CHECKS=0;

DROP DATABASE IF EXISTS `latihanuts2010130010`;

CREATE DATABASE `latihanuts2010130010`
    CHARACTER SET 'latin1'
    COLLATE 'latin1_swedish_ci';

USE `latihanuts2010130010`;

#
# Structure for the `perguruan` table : 
#

DROP TABLE IF EXISTS `perguruan`;

CREATE TABLE `perguruan` (
  `kode_perguruan` varchar(20) NOT NULL,
  `nama_perguruan` varchar(30) NOT NULL,
  `pendiri` varchar(30) NOT NULL,
  `daerah` varchar(20) default NULL,
  `guru_besar` tinyint(3) default '0',
  `pertarungan` int(11) default '0',
  `menang` int(11) default '0',
  PRIMARY KEY  (`kode_perguruan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Definition for the `hapus_perguruan` procedure : 
#

DROP PROCEDURE IF EXISTS `hapus_perguruan`;

CREATE PROCEDURE `hapus_perguruan`(IN a VARCHAR(20))
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY DEFINER
    COMMENT ''
BEGIN
     delete from perguruan where kode_perguruan = a;
     select 'data sudah terhapus HIKS';
END;

#
# Definition for the `tambah_perguruan` procedure : 
#

DROP PROCEDURE IF EXISTS `tambah_perguruan`;

CREATE PROCEDURE `tambah_perguruan`(IN a VARCHAR(20), IN b VARCHAR(30), IN c VARCHAR(30), IN d VARCHAR(20), IN e TINYINT(3), IN f INTEGER(11), IN g INTEGER(11))
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY DEFINER
    COMMENT ''
BEGIN
     declare continue handler for 1062
     select'data sudah ada >_<';
     insert into perguruan values(a,b,c,d,e,f,g);
     select 'Terima Kasih Data sudah Disimpan ^_^';
END;

#
# Definition for the `ubah_perguruan` procedure : 
#

DROP PROCEDURE IF EXISTS `ubah_perguruan`;

CREATE PROCEDURE `ubah_perguruan`(IN a VARCHAR(20), IN b VARCHAR(30), IN c VARCHAR(30), IN d VARCHAR(20), IN e TINYINT(3), IN f INTEGER(11), IN g INTEGER(11))
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY DEFINER
    COMMENT ''
BEGIN
     update perguruan set nama_perguruan = b, pendiri = c, daerah = d, guru_besar=e, pertarungan = f, menang = g where kode_perguruan = a;
     select 'Data telah di ubah ^_^';
END;

#
# Definition for the `kodebaru` function : 
#

DROP FUNCTION IF EXISTS `kodebaru`;

CREATE FUNCTION `kodebaru`(a VARCHAR(20))
    RETURNS varchar(20)
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY DEFINER
    COMMENT ''
begin
  declare n varchar(20);
  declare s varchar(20);
  select max(kode_perguruan) into s from perguruan where upper(kode_perguruan) like(concat(upper(a),'%'));
  if s is null then
     set s = concat(a,'01');
  else
     set s = concat(a,lpad(substr(s,LENGTH(s)-1,2)+1,2,'0'));
  end if;
  return(s);
end;

#
# Definition for the `nama_tingkat` function : 
#

DROP FUNCTION IF EXISTS `nama_tingkat`;

CREATE FUNCTION `nama_tingkat`(a TINYINT(3), b INTEGER(11))
    RETURNS varchar(30)
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY DEFINER
    COMMENT ''
begin
  declare n varchar(30);
  if a>10 and b>500 then
       set n='Dedemit';
  elseif a>5 and b>200 then
       set n ='Jawara';
  elseif a>= 0 and b>50 then
       set n ='Satria';
  elseif a>= 0 and b>10 then
       set n ='Pemula';
  else
      set n ='&nbsp';
  end if;
  return(n);
end;

#
# Data for the `perguruan` table  (LIMIT 0,500)
#

INSERT INTO `perguruan` (`kode_perguruan`, `nama_perguruan`, `pendiri`, `daerah`, `guru_besar`, `pertarungan`, `menang`) VALUES 
  ('Banjarmasin01','Kuda Alay','Asep','Banjarmasin',100,100,100),
  ('Garut01','Gajah rematik','Asep Sunarya','Garut',90,78,99);

COMMIT;


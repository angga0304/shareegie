# SQL Manager 2005 Lite for MySQL 3.7.6.2
# ---------------------------------------
# Host     : localhost
# Port     : 3306
# Database : minggu_tiga


SET FOREIGN_KEY_CHECKS=0;

DROP DATABASE IF EXISTS `minggu_tiga`;

CREATE DATABASE `minggu_tiga`
    CHARACTER SET 'latin1'
    COLLATE 'latin1_swedish_ci';

USE `minggu_tiga`;

#
# Structure for the `kurs` table : 
#

CREATE TABLE `kurs` (
  `id` int(11) NOT NULL auto_increment,
  `kurs_nilai` double(15,3) default NULL,
  `jumlah` double(15,3) default NULL,
  `total` double(15,3) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `obat` table : 
#

CREATE TABLE `obat` (
  `kode_obat` char(8) NOT NULL,
  `nama_obat` varchar(30) NOT NULL,
  `tipe_obat` tinyint(1) default '0',
  `harga_obat` int(11) default '0',
  `keterangan` varchar(100) default '-',
  PRIMARY KEY  (`kode_obat`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for the `kurs` table  (LIMIT 0,500)
#

INSERT INTO `kurs` (`id`, `kurs_nilai`, `jumlah`, `total`) VALUES 
  (1,2000,4,NULL);

COMMIT;

#
# Data for the `obat` table  (LIMIT 0,500)
#

INSERT INTO `obat` (`kode_obat`, `nama_obat`, `tipe_obat`, `harga_obat`, `keterangan`) VALUES 
  ('AB000006','Aspirin',1,3000,'pbat sesak dompet'),
  ('AB000007','zccsxc',0,6465,'dcxcv'),
  ('AB000008','wrfewsdf',1,2000,'aswqade'),
  ('AB000009','qeqwe',1,2000,'werew');

COMMIT;


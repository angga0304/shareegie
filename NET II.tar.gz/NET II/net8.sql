# SQL Manager 2005 Lite for MySQL 3.7.6.2
# ---------------------------------------
# Host     : localhost
# Port     : 3306
# Database : net8


SET FOREIGN_KEY_CHECKS=0;

DROP DATABASE IF EXISTS `net8`;

CREATE DATABASE `net8`
    CHARACTER SET 'latin1'
    COLLATE 'latin1_swedish_ci';

USE `net8`;

#
# Structure for the `barang` table : 
#

DROP TABLE IF EXISTS `barang`;

CREATE TABLE `barang` (
  `kode_barang` char(7) NOT NULL,
  `nama_barang` varchar(20) NOT NULL,
  `satuan` varchar(20) default NULL,
  `harga_barang` double(15,3) default '0.000',
  `stok_barang` int(11) default '0',
  PRIMARY KEY  (`kode_barang`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `pelanggan` table : 
#

DROP TABLE IF EXISTS `pelanggan`;

CREATE TABLE `pelanggan` (
  `kode_pelanggan` char(7) NOT NULL,
  `nama_pelanggan` varchar(20) NOT NULL,
  `almt_pelanggan` text,
  `telp_pelanggan` char(10) default NULL,
  `emac_pelanggan` varchar(20) default NULL,
  PRIMARY KEY  (`kode_pelanggan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `keluar` table : 
#

DROP TABLE IF EXISTS `keluar`;

CREATE TABLE `keluar` (
  `no_surat_jalan` char(10) NOT NULL,
  `tgl_keluar` date NOT NULL,
  `kode_pelanggan` char(7) default NULL,
  PRIMARY KEY  (`no_surat_jalan`),
  KEY `kode_pelanggan` (`kode_pelanggan`),
  CONSTRAINT `keluar_fk` FOREIGN KEY (`kode_pelanggan`) REFERENCES `pelanggan` (`kode_pelanggan`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `detil_keluar` table : 
#

DROP TABLE IF EXISTS `detil_keluar`;

CREATE TABLE `detil_keluar` (
  `no_surat_jalan` char(10) NOT NULL,
  `kode_barang` char(7) NOT NULL,
  `jml_barang` int(11) default '0',
  PRIMARY KEY  (`no_surat_jalan`,`kode_barang`),
  KEY `no_surat_jalan` (`no_surat_jalan`),
  KEY `kode_barang` (`kode_barang`),
  CONSTRAINT `detil_keluar_fk1` FOREIGN KEY (`kode_barang`) REFERENCES `barang` (`kode_barang`) ON UPDATE CASCADE,
  CONSTRAINT `detil_keluar_fk` FOREIGN KEY (`no_surat_jalan`) REFERENCES `keluar` (`no_surat_jalan`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `supplier` table : 
#

DROP TABLE IF EXISTS `supplier`;

CREATE TABLE `supplier` (
  `kode_supplier` char(7) NOT NULL,
  `nama_supplier` varchar(20) NOT NULL,
  `almt_supplier` text,
  `telp_supplier` char(10) default NULL,
  `emac_supplier` varchar(20) default NULL,
  PRIMARY KEY  (`kode_supplier`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `terima` table : 
#

DROP TABLE IF EXISTS `terima`;

CREATE TABLE `terima` (
  `no_surat_jalan` char(10) NOT NULL,
  `tgl_terima` date default NULL,
  `kode_supplier` char(7) default NULL,
  PRIMARY KEY  (`no_surat_jalan`),
  KEY `kode_supplier` (`kode_supplier`),
  CONSTRAINT `terima_fk` FOREIGN KEY (`kode_supplier`) REFERENCES `supplier` (`kode_supplier`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `detil_terima` table : 
#

DROP TABLE IF EXISTS `detil_terima`;

CREATE TABLE `detil_terima` (
  `no_surat_jalan` char(10) NOT NULL,
  `kode_barang` char(7) NOT NULL,
  `juml_barang` int(11) default '0',
  PRIMARY KEY  (`no_surat_jalan`,`kode_barang`),
  KEY `no_surat_jalan` (`no_surat_jalan`),
  KEY `kode_barang` (`kode_barang`),
  CONSTRAINT `detil_terima_fk1` FOREIGN KEY (`kode_barang`) REFERENCES `barang` (`kode_barang`) ON UPDATE CASCADE,
  CONSTRAINT `detil_terima_fk` FOREIGN KEY (`no_surat_jalan`) REFERENCES `terima` (`no_surat_jalan`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for the `barang` table  (LIMIT 0,500)
#

INSERT INTO `barang` (`kode_barang`, `nama_barang`, `satuan`, `harga_barang`, `stok_barang`) VALUES 
  ('BRG01','Domba','ekor',800000,0),
  ('BRG02','Ganja','linting',650000,8);

COMMIT;

#
# Data for the `pelanggan` table  (LIMIT 0,500)
#

INSERT INTO `pelanggan` (`kode_pelanggan`, `nama_pelanggan`, `almt_pelanggan`, `telp_pelanggan`, `emac_pelanggan`) VALUES 
  ('PL01','Angga','Otista 564','520-4647','angga@yahud.com'),
  ('PL02','Ryan','Jombang','675-xxxx','kanibal@geulis.com');

COMMIT;

#
# Data for the `keluar` table  (LIMIT 0,500)
#

INSERT INTO `keluar` (`no_surat_jalan`, `tgl_keluar`, `kode_pelanggan`) VALUES 
  ('SJ01','2013-04-08','PL01'),
  ('SJ02','2013-04-02','PL02');

COMMIT;

#
# Data for the `detil_keluar` table  (LIMIT 0,500)
#

INSERT INTO `detil_keluar` (`no_surat_jalan`, `kode_barang`, `jml_barang`) VALUES 
  ('SJ01','BRG01',3),
  ('SJ02','BRG02',2);

COMMIT;

#
# Data for the `supplier` table  (LIMIT 0,500)
#

INSERT INTO `supplier` (`kode_supplier`, `nama_supplier`, `almt_supplier`, `telp_supplier`, `emac_supplier`) VALUES 
  ('SP01','Aburizal Bahar','Kosambi 97','999-0897','Bahar@yahud.com'),
  ('SP02','Gunawan Dwiputri','Otista 98','543-8756','Gun@geulis.co.id');

COMMIT;

#
# Data for the `terima` table  (LIMIT 0,500)
#

INSERT INTO `terima` (`no_surat_jalan`, `tgl_terima`, `kode_supplier`) VALUES 
  ('SJ002','2013-04-02','SP01'),
  ('SJ01','2013-04-01','SP02');

COMMIT;

#
# Data for the `detil_terima` table  (LIMIT 0,500)
#

INSERT INTO `detil_terima` (`no_surat_jalan`, `kode_barang`, `juml_barang`) VALUES 
  ('SJ002','BRG02',6),
  ('SJ01','BRG01',5);

COMMIT;


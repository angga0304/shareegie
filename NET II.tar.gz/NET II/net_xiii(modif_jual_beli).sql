# SQL Manager 2005 Lite for MySQL 3.7.6.2
# ---------------------------------------
# Host     : localhost
# Port     : 3306
# Database : net_xiii


SET FOREIGN_KEY_CHECKS=0;

DROP DATABASE IF EXISTS `net_xiii`;

CREATE DATABASE `net_xiii`
    CHARACTER SET 'latin1'
    COLLATE 'latin1_swedish_ci';

USE `net_xiii`;

#
# Structure for the `barang` table : 
#

DROP TABLE IF EXISTS `barang`;

CREATE TABLE `barang` (
  `kode_barang` char(5) NOT NULL,
  `nama_barang` varchar(40) default NULL,
  `stok_barang` int(11) default NULL,
  `harga_barang` int(11) default NULL,
  PRIMARY KEY  (`kode_barang`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `supplier` table : 
#

DROP TABLE IF EXISTS `supplier`;

CREATE TABLE `supplier` (
  `kode_supplier` char(5) NOT NULL,
  `nama_supplier` varchar(30) NOT NULL,
  `alamat_supplier` varchar(50) NOT NULL,
  `email` varchar(20) default '-',
  `contact` varchar(20) NOT NULL,
  PRIMARY KEY  (`kode_supplier`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `beli` table : 
#

DROP TABLE IF EXISTS `beli`;

CREATE TABLE `beli` (
  `no_beli` char(10) NOT NULL,
  `tanggal_beli` date NOT NULL,
  `kode_supplier` char(5) default NULL,
  PRIMARY KEY  (`no_beli`),
  KEY `kode_supplier` (`kode_supplier`),
  CONSTRAINT `beli_fk` FOREIGN KEY (`kode_supplier`) REFERENCES `supplier` (`kode_supplier`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `detil_beli` table : 
#

DROP TABLE IF EXISTS `detil_beli`;

CREATE TABLE `detil_beli` (
  `no_beli` char(10) NOT NULL,
  `kode_barang` char(5) NOT NULL,
  `banyak` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  PRIMARY KEY  (`no_beli`,`kode_barang`),
  KEY `kode_barang` (`kode_barang`),
  KEY `no_beli` (`no_beli`),
  CONSTRAINT `detil_beli_fk` FOREIGN KEY (`no_beli`) REFERENCES `beli` (`no_beli`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `detil_beli_fk1` FOREIGN KEY (`kode_barang`) REFERENCES `barang` (`kode_barang`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `pelanggan` table : 
#

DROP TABLE IF EXISTS `pelanggan`;

CREATE TABLE `pelanggan` (
  `kode_pelanggan` char(5) NOT NULL,
  `nama_pelanggan` varchar(30) NOT NULL,
  `alamat_pelanggan` varchar(50) NOT NULL,
  `email` varchar(20) default '-',
  `contact` varchar(20) NOT NULL,
  PRIMARY KEY  (`kode_pelanggan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `jual` table : 
#

DROP TABLE IF EXISTS `jual`;

CREATE TABLE `jual` (
  `no_jual` char(10) NOT NULL,
  `tanggal_jual` date NOT NULL,
  `kode_pelanggan` char(5) default NULL,
  PRIMARY KEY  (`no_jual`),
  KEY `kode_pelanggan` (`kode_pelanggan`),
  CONSTRAINT `jual_fk` FOREIGN KEY (`kode_pelanggan`) REFERENCES `pelanggan` (`kode_pelanggan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `detil_jual` table : 
#

DROP TABLE IF EXISTS `detil_jual`;

CREATE TABLE `detil_jual` (
  `no_jual` char(10) NOT NULL,
  `kode_barang` char(5) NOT NULL,
  `banyak` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  PRIMARY KEY  (`no_jual`,`kode_barang`),
  KEY `kode_barang` (`kode_barang`),
  KEY `no_jual` (`no_jual`),
  CONSTRAINT `detil_jual_fk` FOREIGN KEY (`no_jual`) REFERENCES `jual` (`no_jual`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `detil_jual_fk1` FOREIGN KEY (`kode_barang`) REFERENCES `barang` (`kode_barang`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Definition for the `delete_barang` procedure : 
#

DROP PROCEDURE IF EXISTS `delete_barang`;

CREATE PROCEDURE `delete_barang`(IN kd CHAR(5))
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY INVOKER
    COMMENT ''
BEGIN
delete from barang where kode_barang=kd;
select 'Data Barang BERHASIL dihapus!';
END;

#
# Definition for the `delete_beli` procedure : 
#

DROP PROCEDURE IF EXISTS `delete_beli`;

CREATE PROCEDURE `delete_beli`(IN nom CHAR(10))
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY INVOKER
    COMMENT ''
BEGIN
delete from beli where no_beli=nom;
select 'Data Pembelian BERHASIL dihapus!';
END;

#
# Definition for the `delete_jual` procedure : 
#

DROP PROCEDURE IF EXISTS `delete_jual`;

CREATE PROCEDURE `delete_jual`(IN nom CHAR(10))
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY INVOKER
    COMMENT ''
BEGIN
delete from jual where no_jual=nom;
select 'Data Penjualan BERHASIL dihapus!';
END;

#
# Definition for the `delete_pelanggan` procedure : 
#

DROP PROCEDURE IF EXISTS `delete_pelanggan`;

CREATE PROCEDURE `delete_pelanggan`(IN kd CHAR(5))
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY INVOKER
    COMMENT ''
BEGIN
delete from pelanggan where kode_pelanggan=kd;
select 'Data pelanggan BERHASIL dihapus!';
END;

#
# Definition for the `delete_supplier` procedure : 
#

DROP PROCEDURE IF EXISTS `delete_supplier`;

CREATE PROCEDURE `delete_supplier`(IN kd CHAR(5))
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY INVOKER
    COMMENT ''
BEGIN
delete from supplier where kode_supplier=kd;
select 'Data supplier BERHASIL dihapus!';
END;

#
# Definition for the `insert_barang` procedure : 
#

DROP PROCEDURE IF EXISTS `insert_barang`;

CREATE PROCEDURE `insert_barang`(IN kd CHAR(5), IN nm VARCHAR(40), IN st INTEGER(11), IN hrg INTEGER(11))
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY INVOKER
    COMMENT ''
BEGIN
declare kosong tinyint default 0;
declare n char(5);
declare cur cursor for select kode_barang FROM
        barang where kode_barang=kd;
declare continue handler FOR
        not found set kosong=1;
        
open cur;
fetch cur into n;
close cur;
if kosong =1 then
   insert into barang (kode_barang,nama_barang,stok_barang,harga_barang)
   values (kd,nm,st,hrg);
   select'Data BERHASIL ditambahkan';
ELSE
update  barang set kode_barang=kd,nama_barang=nm,stok_barang=st,harga_barang=hrg
   where kode_barang=kd;
   select'Data BERHASIL diupdate';
 end if;

END;

#
# Definition for the `insert_beli` procedure : 
#

DROP PROCEDURE IF EXISTS `insert_beli`;

CREATE PROCEDURE `insert_beli`(IN nom CHAR(10), IN tgl DATE, IN kd CHAR(5))
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY INVOKER
    COMMENT ''
BEGIN
declare kosong tinyint default 0;
declare n char(10);
declare cur cursor for select no_beli FROM
        beli where no_beli=nom;
declare continue handler FOR
        not found set kosong=1;

open cur;
fetch cur into n;
close cur;
if kosong =1 then
   insert into beli (no_beli,tanggal_beli,kode_supplier)
   values (nom,tgl,kd);
   select'Data BERHASIL ditambahkan';
ELSE
update beli set no_beli=nom,tanggal_beli=tgl,kode_supplier=kd
   where no_beli=nom;
   select'Data BERHASIL diupdate';
 end if;

END;

#
# Definition for the `insert_detil_beli` procedure : 
#

DROP PROCEDURE IF EXISTS `insert_detil_beli`;

CREATE PROCEDURE `insert_detil_beli`(IN no CHAR(10), IN kd CHAR(5), IN byk INTEGER(11), IN hg INTEGER(11))
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY INVOKER
    COMMENT ''
BEGIN
     insert into detil_beli
            values (no,kd,byk,hg);
END;

#
# Definition for the `insert_detil_jual` procedure : 
#

DROP PROCEDURE IF EXISTS `insert_detil_jual`;

CREATE PROCEDURE `insert_detil_jual`(IN no CHAR(10), IN kd CHAR(5), IN byk INTEGER(11), IN hg INTEGER(11))
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY INVOKER
    COMMENT ''
BEGIN
     insert into detil_jual
            values (no,kd,byk,hg);
END;

#
# Definition for the `insert_jual` procedure : 
#

DROP PROCEDURE IF EXISTS `insert_jual`;

CREATE PROCEDURE `insert_jual`(IN nom CHAR(10), IN tgl DATE, IN kd CHAR(5))
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY INVOKER
    COMMENT ''
BEGIN
declare kosong tinyint default 0;
declare n char(10);
declare cur cursor for select no_jual FROM
        jual where no_jual=nom;
declare continue handler FOR
        not found set kosong=1;

open cur;
fetch cur into n;
close cur;
if kosong =1 then
   insert into jual (no_jual,tanggal_jual,kode_pelanggan)
   values (nom,tgl,kd);
   select'Data BERHASIL ditambahkan';
ELSE
update  jual set no_jual=nom,tanggal_jual=tgl,kode_pelanggan=kd
   where no_jual=nom;
   select'Data BERHASIL diupdate';
 end if;

END;

#
# Definition for the `insert_pelanggan` procedure : 
#

DROP PROCEDURE IF EXISTS `insert_pelanggan`;

CREATE PROCEDURE `insert_pelanggan`(IN kd CHAR(5), IN nm VARCHAR(30), IN al VARCHAR(50), IN em VARCHAR(20), IN con VARCHAR(20))
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY INVOKER
    COMMENT ''
BEGIN
declare kosong tinyint default 0;
declare n char(5);
declare cur cursor for select kode_pelanggan FROM
        pelanggan where kode_pelanggan=kd;
declare continue handler FOR
        not found set kosong=1;

open cur;
fetch cur into n;
close cur;
if kosong =1 then
   insert into pelanggan (kode_pelanggan,nama_pelanggan,alamat_pelanggan,email,contact)
   values (kd,nm,al,em,con);
   select'Data BERHASIL ditambahkan';
ELSE
update  pelanggan set kode_pelanggan=kd,nama_pelanggan=nm,alamat_pelanggan=al,email=em,contact=con
   where kode_pelanggan=kd;
   select'Data BERHASIL diupdate';
 end if;

END;

#
# Definition for the `insert_supplier` procedure : 
#

DROP PROCEDURE IF EXISTS `insert_supplier`;

CREATE PROCEDURE `insert_supplier`(IN kd CHAR(5), IN nm VARCHAR(30), IN al VARCHAR(50), IN em VARCHAR(20), IN con VARCHAR(20))
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY INVOKER
    COMMENT ''
BEGIN
declare kosong tinyint default 0;
declare n char(5);
declare cur cursor for select kode_supplier FROM
        supplier where kode_supplier=kd;
declare continue handler FOR
        not found set kosong=1;

open cur;
fetch cur into n;
close cur;
if kosong =1 then
   insert into supplier (kode_supplier,nama_supplier,alamat_supplier,email,contact)
   values (kd,nm,al,em,con);
   select'Data BERHASIL ditambahkan';
ELSE
update supplier set kode_supplier=kd,nama_supplier=nm,alamat_supplier=al,email=em,contact=con
   where kode_supplier=kd;
   select'Data BERHASIL diupdate';
 end if;

END;

#
# Definition for the `kdbrg_baru` function : 
#

DROP FUNCTION IF EXISTS `kdbrg_baru`;

CREATE FUNCTION `kdbrg_baru`()
    RETURNS char(5)
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY DEFINER
    COMMENT ''
begin
     declare kdbrg char(5);
     declare tamp char(4);
     declare cur cursor for select max(kode_barang) from barang
                            where substr(kode_barang,1,3)=concat(substr(year(curdate()),3,2),'B');
     open cur;
     fetch cur into kdbrg;
     close cur;


     if kdbrg is null then
        return(concat(substr(year(curdate()),3,2),'B','01'));
     else
        set tamp = concat(substr(kdbrg,1,2),substr(kdbrg,4,2))+1;
        return(concat(substr(tamp,1,2),'B',substr(tamp,3,2)));
     end if;
end;

#
# Definition for the `kdplg_baru` function : 
#

DROP FUNCTION IF EXISTS `kdplg_baru`;

CREATE FUNCTION `kdplg_baru`()
    RETURNS char(5)
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY DEFINER
    COMMENT ''
begin
     declare kdplg char(5);
     declare cur cursor for select max(kode_pelanggan) from pelanggan
                            where substr(kode_pelanggan,1,3)=concat('x',substr(year(curdate()),3,2));
     open cur;
     fetch cur into kdplg;
     close cur;


     if kdplg is null then
        return(concat('x',substr(year(curdate()),3,2),'01'));
     else
        return(concat('x',substr(kdplg,2,4)+1));
     end if;
end;

#
# Definition for the `kdsup_baru` function : 
#

DROP FUNCTION IF EXISTS `kdsup_baru`;

CREATE FUNCTION `kdsup_baru`()
    RETURNS char(5)
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY DEFINER
    COMMENT ''
begin
     declare kdsup char(5);
     declare cur cursor for select max(kode_supplier) from supplier
                            where substr(kode_supplier,1,3)=concat('s',substr(year(curdate()),3,2));
     open cur;
     fetch cur into kdsup;
     close cur;


     if kdsup is null then
        return(concat('s',substr(year(curdate()),3,2),'01'));
     else
        return(concat('s',substr(kdsup,2,4)+1));
     end if;
end;

#
# Definition for the `nojual_baru` function : 
#

DROP FUNCTION IF EXISTS `nojual_baru`;

CREATE FUNCTION `nojual_baru`()
    RETURNS char(10)
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY INVOKER
    COMMENT ''
begin
     declare noju char(10);
     declare cur cursor for select max(no_jual) from jual
                            where substr(no_jual,1,4)=concat(substr(year(curdate()),3,2),
                            DATE_FORMAT(curdate(),'%m'));
     open cur;
     fetch cur into noju;
     close cur;


     if noju is null then
        return(concat(substr(year(curdate()),3,2),DATE_FORMAT(curdate(),'%m'),'000001'));
     else
        return(noju+1);
     end if;
     end;

#
# Data for the `barang` table  (LIMIT 0,500)
#

INSERT INTO `barang` (`kode_barang`, `nama_barang`, `stok_barang`, `harga_barang`) VALUES 
  ('13B19','test',10,500),
  ('BK001','Buku Tulis',20,1500),
  ('BK002','Buku Folio',50,5000),
  ('BK003','Testing Insert',1,99),
  ('PN001','Pensil HB',15,2500),
  ('PN002','Pensil 2B',30,1500);

COMMIT;

#
# Data for the `supplier` table  (LIMIT 0,500)
#

INSERT INTO `supplier` (`kode_supplier`, `nama_supplier`, `alamat_supplier`, `email`, `contact`) VALUES 
  ('S0001','PT. Cakra','Mampang Prapatan','-','123456'),
  ('S0002','CV. Mitra Utama','Jl Banda No. 2','-','321654');

COMMIT;

#
# Data for the `beli` table  (LIMIT 0,500)
#

INSERT INTO `beli` (`no_beli`, `tanggal_beli`, `kode_supplier`) VALUES 
  ('MU0001','2013-03-11','S0002'),
  ('XX0001','2013-03-13','S0001');

COMMIT;

#
# Data for the `detil_beli` table  (LIMIT 0,500)
#

INSERT INTO `detil_beli` (`no_beli`, `kode_barang`, `banyak`, `harga`) VALUES 
  ('MU0001','BK001',5,2000),
  ('XX0001','PN001',2,1500),
  ('XX0001','PN002',5,2000);

COMMIT;

#
# Data for the `pelanggan` table  (LIMIT 0,500)
#

INSERT INTO `pelanggan` (`kode_pelanggan`, `nama_pelanggan`, `alamat_pelanggan`, `email`, `contact`) VALUES 
  ('A0001','Aelke Mariska','Reminiscence 77','-','123456'),
  ('A0002','Haruna Ono','Scandal 123','-','987654'),
  ('A0003','Testing Insert','asdf','asdf','16345'),
  ('PG001','Randy Saputra','-','-','123456789'),
  ('PG002','Sandy Saputra','-','-','987654321');

COMMIT;

#
# Data for the `jual` table  (LIMIT 0,500)
#

INSERT INTO `jual` (`no_jual`, `tanggal_jual`, `kode_pelanggan`) VALUES 
  ('1303000001','2013-03-13','A0001'),
  ('1303000002','2013-03-14','A0002');

COMMIT;

#
# Data for the `detil_jual` table  (LIMIT 0,500)
#

INSERT INTO `detil_jual` (`no_jual`, `kode_barang`, `banyak`, `harga`) VALUES 
  ('1303000001','BK001',5,2000),
  ('1303000002','BK002',10,1500);

COMMIT;


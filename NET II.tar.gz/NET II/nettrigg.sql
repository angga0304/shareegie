# SQL Manager 2005 Lite for MySQL 3.7.6.2
# ---------------------------------------
# Host     : localhost
# Port     : 3306
# Database : nettrigg


SET FOREIGN_KEY_CHECKS=0;

DROP DATABASE IF EXISTS `nettrigg`;

CREATE DATABASE `nettrigg`
    CHARACTER SET 'latin1'
    COLLATE 'latin1_swedish_ci';

USE `nettrigg`;

#
# Structure for the `akun` table : 
#

DROP TABLE IF EXISTS `akun`;

CREATE TABLE `akun` (
  `no_rekenimg` char(10) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `saldo` int(11) default '0',
  PRIMARY KEY  (`no_rekenimg`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Structure for the `penarikan` table : 
#

DROP TABLE IF EXISTS `penarikan`;

CREATE TABLE `penarikan` (
  `no_transaksi` char(10) NOT NULL,
  `waktu` datetime NOT NULL,
  `no_rekening` char(10) default NULL,
  `jumlah_penarikan` int(11) NOT NULL,
  PRIMARY KEY  (`no_transaksi`),
  KEY `no_rekening` (`no_rekening`),
  CONSTRAINT `penarikan_fk` FOREIGN KEY (`no_rekening`) REFERENCES `akun` (`no_rekenimg`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TRIGGER `penarikan_before_ins_tr` BEFORE INSERT ON `penarikan`
  FOR EACH ROW
BEGIN

END;

CREATE TRIGGER `penarikan_before_del_tr` BEFORE DELETE ON `penarikan`
  FOR EACH ROW
BEGIN

END;

#
# Structure for the `penyetoran` table : 
#

DROP TABLE IF EXISTS `penyetoran`;

CREATE TABLE `penyetoran` (
  `np_transaksi` char(10) NOT NULL,
  `waktu` datetime NOT NULL,
  `no_rekening` char(10) default NULL,
  `jumlah_setoran` int(11) NOT NULL,
  PRIMARY KEY  (`np_transaksi`),
  KEY `no_rekening` (`no_rekening`),
  CONSTRAINT `penyetoran_fk` FOREIGN KEY (`no_rekening`) REFERENCES `akun` (`no_rekenimg`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TRIGGER `penyetoran_after_ins_tr` AFTER INSERT ON `penyetoran`
  FOR EACH ROW
BEGIN
     update akun set saldo = saldo + new.jumlah_setoran where no_rekenimg = new.no_rekening;
END;

CREATE TRIGGER `penyetoran_after_upd_tr` AFTER UPDATE ON `penyetoran`
  FOR EACH ROW
BEGIN
     update akun set saldo = saldo - old.jumlah_setoran + new.jumlah_setoran
     where no_rekenimg = new.no_rekening;
END;

CREATE TRIGGER `penyetoran_before_del_tr` BEFORE DELETE ON `penyetoran`
  FOR EACH ROW
BEGIN
     update akun set saldo = saldo-old.jumlah_setoran
     where no_rekenimg = old.no_rekening;
END;

#
# Data for the `akun` table  (LIMIT 0,500)
#

INSERT INTO `akun` (`no_rekenimg`, `nama`, `saldo`) VALUES 
  ('2013000001','Dana Arta',0),
  ('2013000002','Sinta',10000000),
  ('2013000003','Edward',0),
  ('2013000004','Rikki',0),
  ('2013000005','Billy',0);

COMMIT;

#
# Data for the `penyetoran` table  (LIMIT 0,500)
#

INSERT INTO `penyetoran` (`np_transaksi`, `waktu`, `no_rekening`, `jumlah_setoran`) VALUES 
  ('201304001','2013-04-29 16:15:51','2013000002',10000000);

COMMIT;


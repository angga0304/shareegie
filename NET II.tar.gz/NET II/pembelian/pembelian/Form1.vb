﻿Imports MySql.Data.MySqlClient
Public Class Form1
    Protected Const SQL_CONNECTION_STRING As String = _
        "Server=localhost;Port=3306;Database=pembelian;UID=root;PWD='likmi'"
    Private dsDetilBeli As DataSet
    Private dtBeli As DataTable
    Private dtDetilBeli As DataTable
    Private dvBeli As DataView
    Private dvDetilBeli As DataView
    Private sda As MySqlDataAdapter
    Protected strConn As String = SQL_CONNECTION_STRING
    Private adapter As MySqlDataAdapter
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CreateDataSet()
        InitializeBindings()
        BindOrdersGrid()
        ShowCurrentRecordNumber()
        konek("localhost", "3306", "root", "likmi", "pembelian")
        IsiComboBox()
    End Sub

    Sub CreateDataSet()
        Try
            Dim scnnNW As New MySqlConnection(strConn)
            Dim strSQL As String = _
                "SELECT kode_penerimaan,tanggal,kode_supplier,nama_supplier," & _
                "sum(banyak*harga) as total " & _
                "FROM barang_masuk a inner join dbarang_masuk b using(kode_penerimaan) inner join " & _
                "supplier using(kode_supplier) group by a.kode_penerimaan " & _
                "order by kode_penerimaan"

            Dim scmd As New MySqlCommand(strSQL, scnnNW)

            sda = New MySqlDataAdapter(scmd)

            Dim scb As New MySqlCommandBuilder(sda)

            dsDetilBeli = New DataSet()
            sda.Fill(dsDetilBeli, "Beli")

            scmd.CommandText = _
                "SELECT kode_penerimaan,kode_barang,nama_barang,harga,banyak," & _
                "harga*banyak as jumlah from dbarang_masuk a inner join barang " & _
                "using(kode_barang) order by kode_penerimaan,kode_barang"

            sda.Fill(dsDetilBeli, "DetilBeli")

            dtBeli = dsDetilBeli.Tables(0)
            dtDetilBeli = dsDetilBeli.Tables(1)

            dvBeli = dtBeli.DefaultView
            dvDetilBeli = dtDetilBeli.DefaultView

        Catch expSql As MySqlException
            MsgBox(expSql.Message, MsgBoxStyle.Critical, Me.Text)
            Exit Sub
        End Try
    End Sub

    Private Sub InitializeBindings()
        lblpenerimaan.DataBindings.Clear()
        lblpenerimaan.DataBindings.Add("Text", dtBeli, "kode_penerimaan")
        lblsupplier.DataBindings.Clear()
        lblsupplier.DataBindings.Add("Text", dtBeli, "kode_supplier")
        cbsup.DataBindings.Clear()
        cbsup.DataBindings.Add("Text", dtBeli, "nama_supplier")
        Total.DataBindings.Clear()
        Total.DataBindings.Add("Text", dtBeli, "total")
        stpdpembelian.DataBindings.Clear()
        stpdpembelian.DataBindings.Add("Value", dtBeli, "tanggal")

        AddHandler Me.BindingContext(dtBeli).PositionChanged, _
            AddressOf dtBeli_PositionChanged
    End Sub
    Protected Sub dtBeli_PositionChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        BindOrdersGrid()
        ShowCurrentRecordNumber()
    End Sub
    Sub BindOrdersGrid()
        dvDetilBeli.RowFilter = "kode_penerimaan = '" & lblpenerimaan.Text & "'"
        DataGridView2.DataSource = dvDetilBeli
    End Sub

    Protected Sub ShowCurrentRecordNumber()
        strrecord.Text = "Data ke " & _
           Me.BindingContext(dtBeli).Position + 1 & " dari " & _
              dtBeli.Rows.Count
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.BindingContext(dtBeli).Position = 0
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Me.BindingContext(dtBeli).Position -= 1
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Me.BindingContext(dtBeli).Position += 1
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Me.BindingContext(dtBeli).Position = dtBeli.Rows.Count - 1
    End Sub

    Sub IsiComboBox()
        Dim dt As New DataTable
        Try
            adapter = New MySqlDataAdapter( _
                "select nama_supplier from " & _
                "supplier order by nama_supplier", Conn)
            adapter.Fill(dt)
            ComboBox1.Items.Clear()
            For i = 0 To dt.Rows.Count - 1
                ComboBox1.Items.Add(dt.Rows(i)(0).ToString)
            Next i
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            Conn.Close()
        End Try
    End Sub

    Private Sub eksekusi(ByVal str1 As String)
        Dim sqlstr As String = str1
        Dim dt As New DataTable
        Try
            adapter = New MySqlDataAdapter(sqlstr, Conn)
            adapter.Fill(dt)
            'MsgBox(dt.Rows(0)(0).ToString, _
            '       MsgBoxStyle.Information, "Informasi")
        Catch ex As Exception
            'MsgBox(ex.Message.ToString, _
            '       MsgBoxStyle.Information, "Pesan")
        End Try
        Conn.Close()
    End Sub


    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        eksekusi("call insert_beli('" & _
                 txtkodepenerimaan.Text & "','" & _
                 Format(dtppembelian.Value, "yyyy-MM-dd") & _
                 "','" & txtkodesup.Text & "')")
        For i = 0 To DataGridView2.Rows.Count - 2
            eksekusi("call insert_detil_beli('" & _
                 txtkodepenerimaan.Text & "','" & _
                 DataGridView2(0, i).Value & "','" & _
                 DataGridView2(3, i).Value & "','" & _
                 DataGridView2(2, i).Value & "')")
        Next i
        Form1_Load(Me, e)
    End Sub
End Class

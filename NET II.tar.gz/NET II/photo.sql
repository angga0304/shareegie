# SQL Manager 2005 Lite for MySQL 3.7.6.2
# ---------------------------------------
# Host     : localhost
# Port     : 3306
# Database : photo


SET FOREIGN_KEY_CHECKS=0;

DROP DATABASE IF EXISTS `photo`;

CREATE DATABASE `photo`
    CHARACTER SET 'latin1'
    COLLATE 'latin1_swedish_ci';

USE `photo`;

#
# Structure for the `registration` table : 
#

DROP TABLE IF EXISTS `registration`;

CREATE TABLE `registration` (
  `nomor` char(10) NOT NULL,
  `firstname` varchar(10) NOT NULL,
  `midlename` varchar(10) default NULL,
  `lastname` char(10) default NULL,
  `company` text,
  `school` text,
  `fax` varchar(25) default NULL,
  `phone` varchar(20) default NULL,
  `website` varchar(20) default NULL,
  `email` varchar(20) default NULL,
  `age` tinyint(4) NOT NULL,
  `profession` varchar(20) default NULL,
  `year` int(2) default NULL,
  `awards` varchar(20) default NULL,
  `club` varchar(20) default NULL,
  `comment` text,
  PRIMARY KEY  (`nomor`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Definition for the `kodebaru` function : 
#

DROP FUNCTION IF EXISTS `kodebaru`;

CREATE FUNCTION `kodebaru`()
    RETURNS char(10)
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY DEFINER
    COMMENT ''
BEGIN
     declare an char(7);
     set an = concat('F',year(now()),MONTH(now()));
     return(an);
end;


﻿Public Class Form2

    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'net_xiii.pelanggan' table. You can move, or remove it, as needed.
        Me.pelangganTableAdapter.Fill(Me.net_xiii.pelanggan)

        Me.ReportViewer1.RefreshReport()
    End Sub
End Class